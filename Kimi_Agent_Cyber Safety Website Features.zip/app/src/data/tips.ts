export interface DailyTip {
  id: number;
  title: string;
  content: string;
  category: string;
}

export const dailyTips: DailyTip[] = [
  {
    id: 1,
    title: "Enable Two-Factor Authentication",
    content: "Add an extra layer of security to your accounts by enabling 2FA. Even if someone gets your password, they can't access your account without the second verification step.",
    category: "Authentication"
  },
  {
    id: 2,
    title: "Use a Password Manager",
    content: "Password managers generate and store strong, unique passwords for every account. You only need to remember one master password.",
    category: "Passwords"
  },
  {
    id: 3,
    title: "Beware of Public WiFi",
    content: "Avoid accessing banking or entering passwords on public WiFi. Use a VPN or your mobile hotspot for sensitive activities.",
    category: "Network"
  },
  {
    id: 4,
    title: "Keep Software Updated",
    content: "Software updates often include critical security patches. Enable automatic updates on all your devices and applications.",
    category: "Updates"
  },
  {
    id: 5,
    title: "Verify Before You Click",
    content: "Hover over links to see the actual URL before clicking. Phishers often disguise malicious links behind legitimate-looking text.",
    category: "Phishing"
  },
  {
    id: 6,
    title: "Backup Your Data Regularly",
    content: "Follow the 3-2-1 rule: keep 3 copies of your data, on 2 different media types, with 1 stored offsite or in the cloud.",
    category: "Backup"
  },
  {
    id: 7,
    title: "Review App Permissions",
    content: "Regularly check what permissions your apps have. A flashlight app doesn't need access to your contacts or location.",
    category: "Privacy"
  },
  {
    id: 8,
    title: "Use Strong, Unique Passwords",
    content: "Each account should have a unique password of at least 12 characters with a mix of letters, numbers, and symbols.",
    category: "Passwords"
  },
  {
    id: 9,
    title: "Be Cautious with QR Codes",
    content: "Inspect QR codes in public for stickers placed over originals. Use a scanner that previews the URL before opening.",
    category: "Scams"
  },
  {
    id: 10,
    title: "Monitor Your Accounts",
    content: "Regularly check bank statements and credit reports for unauthorized activity. Set up alerts for all financial transactions.",
    category: "Monitoring"
  },
  {
    id: 11,
    title: "Don't Overshare on Social Media",
    content: "Avoid posting personal details like birthdate, address, or vacation plans. Scammers use this information for identity theft.",
    category: "Privacy"
  },
  {
    id: 12,
    title: "Secure Your Home Network",
    content: "Change default router passwords, enable WPA3 encryption, and hide your network SSID for better security.",
    category: "Network"
  },
  {
    id: 13,
    title: "Verify Caller Identity",
    content: "Scammers can spoof caller IDs. If someone claims to be from your bank, hang up and call the official number.",
    category: "Scams"
  },
  {
    id: 14,
    title: "Use Encrypted Messaging",
    content: "For sensitive conversations, use end-to-end encrypted messaging apps like Signal instead of standard SMS.",
    category: "Privacy"
  },
  {
    id: 15,
    title: "Be Skeptical of Urgency",
    content: "Scammers create false urgency to pressure quick decisions. Take time to verify any urgent request independently.",
    category: "Scams"
  },
  {
    id: 16,
    title: "Secure Your Mobile Devices",
    content: "Use biometric locks, enable remote wipe capability, and encrypt your phone's storage for maximum protection.",
    category: "Devices"
  },
  {
    id: 17,
    title: "Don't Ignore Security Warnings",
    content: "Browser security warnings exist for a reason. If your browser says a site is unsafe, trust it and leave immediately.",
    category: "Browsing"
  },
  {
    id: 18,
    title: "Dispose of Devices Securely",
    content: "Before selling or recycling old devices, perform a factory reset and remove all storage media including SD cards.",
    category: "Devices"
  },
  {
    id: 19,
    title: "Learn to Recognize Deepfakes",
    content: "Watch for unnatural blinking, inconsistent lighting, and mismatched audio in videos. Verify shocking content through multiple sources.",
    category: "AI Threats"
  },
  {
    id: 20,
    title: "Report Cybercrime",
    content: "If you fall victim to cybercrime, report it immediately to local authorities and cybercrime units. Early reporting increases recovery chances.",
    category: "Response"
  },
  {
    id: 21,
    title: "Use Email Aliases",
    content: "Create different email aliases for different purposes. If one gets compromised, your other accounts remain safe.",
    category: "Email"
  },
  {
    id: 22,
    title: "Enable Find My Device",
    content: "Activate location tracking on all devices. If lost or stolen, you can locate, lock, or erase them remotely.",
    category: "Devices"
  },
  {
    id: 23,
    title: "Be Careful with USB Drives",
    content: "Never plug in unknown USB drives. They can contain malware that auto-executes when connected to your computer.",
    category: "Malware"
  },
  {
    id: 24,
    title: "Check Website Security",
    content: "Always look for the padlock icon and 'https://' in the address bar before entering sensitive information on websites.",
    category: "Browsing"
  },
  {
    id: 25,
    title: "Educate Your Family",
    content: "Share cybersecurity knowledge with family members, especially children and elderly who are common targets for scammers.",
    category: "Education"
  },
  {
    id: 26,
    title: "Use Ad Blockers",
    content: "Ad blockers prevent malicious advertisements from loading, reducing your exposure to malvertising attacks.",
    category: "Browsing"
  },
  {
    id: 27,
    title: "Disable Auto-Downloads",
    content: "Turn off automatic downloads in messaging apps and email clients to prevent malware from installing without your knowledge.",
    category: "Malware"
  },
  {
    id: 28,
    title: "Create a Family Emergency Code",
    content: "Establish a secret code word with family members to verify identity during emergency requests for money or help.",
    category: "Scams"
  },
  {
    id: 29,
    title: "Review Privacy Settings Monthly",
    content: "Social media platforms frequently update privacy settings. Schedule a monthly review to ensure your data stays protected.",
    category: "Privacy"
  },
  {
    id: 30,
    title: "Trust Your Instincts",
    content: "If something feels off about an email, call, or website, trust your gut. It's better to be cautious than to become a victim.",
    category: "General"
  }
];

export function getDailyTip(): DailyTip {
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
  return dailyTips[dayOfYear % dailyTips.length];
}
