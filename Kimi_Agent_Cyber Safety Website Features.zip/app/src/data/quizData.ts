export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What should you do if you receive an unexpected email asking for your password?",
    options: [
      "Reply with your password",
      "Click the link and enter your credentials",
      "Delete it and report as phishing",
      "Forward it to your friends to warn them"
    ],
    correctAnswer: 2,
    explanation: "Legitimate organizations never ask for passwords via email. Always delete suspicious emails and report them."
  },
  {
    id: 2,
    question: "Which of the following is the strongest password?",
    options: [
      "password123",
      "YourName2024",
      "Xk9#mP2$vLq@7!wR",
      "qwerty"
    ],
    correctAnswer: 2,
    explanation: "A strong password uses a mix of uppercase, lowercase, numbers, and special characters with no predictable patterns."
  },
  {
    id: 3,
    question: "What does 'HTTPS' in a URL indicate?",
    options: [
      "The website is free to use",
      "The connection is encrypted and secure",
      "The website loads faster",
      "The website is government-approved"
    ],
    correctAnswer: 1,
    explanation: "HTTPS (HyperText Transfer Protocol Secure) encrypts data between your browser and the website, protecting your information."
  },
  {
    id: 4,
    question: "What is Two-Factor Authentication (2FA)?",
    options: [
      "Using two different passwords",
      "A security method requiring two different verification methods",
      "Having two email accounts",
      "Using two different devices"
    ],
    correctAnswer: 1,
    explanation: "2FA adds an extra layer of security by requiring something you know (password) plus something you have (phone/code)."
  },
  {
    id: 5,
    question: "Which is a common sign of a phishing email?",
    options: [
      "Perfect grammar and spelling",
      "Comes from a known contact",
      "Urgent language demanding immediate action",
      "Contains company logo"
    ],
    correctAnswer: 2,
    explanation: "Phishing emails often use urgent language ('Act now!', 'Account suspended') to pressure you into acting without thinking."
  },
  {
    id: 6,
    question: "What is malware?",
    options: [
      "A type of antivirus software",
      "Software designed to harm or exploit devices",
      "A secure messaging app",
      "A website firewall"
    ],
    correctAnswer: 1,
    explanation: "Malware (malicious software) includes viruses, trojans, ransomware, and spyware designed to damage or steal data."
  },
  {
    id: 7,
    question: "What should you do before clicking a link in an email?",
    options: [
      "Click immediately if it looks important",
      "Hover over it to check the actual URL",
      "Forward it to IT after clicking",
      "Always trust links from known senders"
    ],
    correctAnswer: 1,
    explanation: "Hovering reveals the true destination URL. Phishers often mask malicious URLs behind legitimate-looking text."
  },
  {
    id: 8,
    question: "What is ransomware?",
    options: [
      "Software that speeds up your computer",
      "Malware that encrypts files and demands payment",
      "A free antivirus program",
      "A type of secure backup"
    ],
    correctAnswer: 1,
    explanation: "Ransomware encrypts your files, making them inaccessible until you pay a ransom (which doesn't guarantee recovery)."
  },
  {
    id: 9,
    question: "Why should you keep software updated?",
    options: [
      "To get new features only",
      "Updates are optional and unnecessary",
      "To patch security vulnerabilities",
      "To make your computer slower"
    ],
    correctAnswer: 2,
    explanation: "Software updates often include security patches that fix vulnerabilities hackers could exploit."
  },
  {
    id: 10,
    question: "What is social engineering in cybersecurity?",
    options: [
      "Building secure social networks",
      "Manipulating people into revealing confidential information",
      "Engineering social media algorithms",
      "Creating strong passwords"
    ],
    correctAnswer: 1,
    explanation: "Social engineering exploits human psychology rather than technical hacking to gain access to systems or data."
  },
  {
    id: 11,
    question: "What does a VPN do?",
    options: [
      "Makes your internet slower",
      "Encrypts your internet connection for privacy",
      "Blocks all websites",
      "Only works on public WiFi"
    ],
    correctAnswer: 1,
    explanation: "A Virtual Private Network encrypts your internet traffic, protecting your data from eavesdroppers."
  },
  {
    id: 12,
    question: "Which WiFi network is safest to use in a coffee shop?",
    options: [
      "The one with the strongest signal",
      "The one named 'FreeWiFi'",
      "A password-protected network or your mobile hotspot",
      "Any open network without a password"
    ],
    correctAnswer: 2,
    explanation: "Open WiFi networks are easily intercepted. Use password-protected networks or your phone's hotspot for security."
  },
  {
    id: 13,
    question: "What is a deepfake?",
    options: [
      "A type of antivirus scan",
      "AI-generated fake video or audio that looks real",
      "A secure password method",
      "A website encryption protocol"
    ],
    correctAnswer: 1,
    explanation: "Deepfakes use AI to create convincing fake videos/audio, often used for fraud, misinformation, or identity theft."
  },
  {
    id: 14,
    question: "What should you do if you suspect identity theft?",
    options: [
      "Wait and see if anything happens",
      "Contact your bank, freeze credit, and file a report",
      "Change only your email password",
      "Post about it on social media"
    ],
    correctAnswer: 1,
    explanation: "Act quickly: contact financial institutions, freeze your credit, change passwords, and report to authorities."
  },
  {
    id: 15,
    question: "What is a QR code scam?",
    options: [
      "A legitimate marketing tool",
      "When scammers replace real QR codes with malicious ones",
      "A type of antivirus software",
      "A secure payment method"
    ],
    correctAnswer: 1,
    explanation: "Scammers place fake QR codes over real ones. Scanning can lead to phishing sites or malware downloads."
  },
  {
    id: 16,
    question: "Why is it risky to use the same password for multiple accounts?",
    options: [
      "It's harder to remember",
      "If one account is breached, all accounts are at risk",
      "It slows down your computer",
      "Passwords expire faster"
    ],
    correctAnswer: 1,
    explanation: "Credential stuffing attacks use leaked passwords from one breach to access your other accounts."
  },
  {
    id: 17,
    question: "What is a firewall?",
    options: [
      "A physical wall in data centers",
      "Software/hardware that monitors and controls network traffic",
      "A type of computer virus",
      "A backup storage device"
    ],
    correctAnswer: 1,
    explanation: "Firewalls act as barriers between your network and the internet, blocking unauthorized access."
  },
  {
    id: 18,
    question: "What should you check before downloading an app?",
    options: [
      "Only the app icon design",
      "Reviews, developer info, and permissions requested",
      "How many downloads it has",
      "If it's free"
    ],
    correctAnswer: 1,
    explanation: "Check reviews, verify the developer, and review permissions. Malicious apps often request excessive access."
  },
  {
    id: 19,
    question: "What is the best way to backup important data?",
    options: [
      "Store it on one USB drive",
      "Email it to yourself",
      "Use the 3-2-1 rule: 3 copies, 2 media types, 1 offsite",
      "Print everything"
    ],
    correctAnswer: 2,
    explanation: "The 3-2-1 backup rule ensures redundancy: 3 copies, on 2 different media, with 1 stored offsite or in cloud."
  },
  {
    id: 20,
    question: "What should you do if you accidentally click a suspicious link?",
    options: [
      "Nothing, it probably fine",
      "Disconnect from internet, run antivirus, change passwords",
      "Close the browser and forget about it",
      "Tell your friends to click it too"
    ],
    correctAnswer: 1,
    explanation: "Immediately disconnect, scan for malware, change passwords from a clean device, and monitor accounts."
  }
];
