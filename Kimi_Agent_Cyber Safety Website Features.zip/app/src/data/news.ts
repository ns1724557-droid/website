export interface NewsItem {
  id: number;
  title: string;
  summary: string;
  date: string;
  category: string;
  severity: "High" | "Medium" | "Low";
}

export const newsData: NewsItem[] = [
  {
    id: 1,
    title: "Major Ransomware Attack Hits Healthcare Systems",
    summary: "A sophisticated ransomware group has targeted multiple hospital networks, encrypting patient records and demanding cryptocurrency payments. Healthcare organizations are urged to patch vulnerabilities immediately.",
    date: "2026-07-05",
    category: "Ransomware",
    severity: "High"
  },
  {
    id: 2,
    title: "New AI-Powered Phishing Campaign Detected",
    summary: "Cybersecurity researchers have identified phishing emails that use generative AI to perfectly mimic writing styles of known contacts, making them extremely difficult to detect through traditional methods.",
    date: "2026-07-03",
    category: "Phishing",
    severity: "High"
  },
  {
    id: 3,
    title: "Critical Vulnerability Found in Popular Browser Extension",
    summary: "A widely-used password manager browser extension contains a critical vulnerability that could allow attackers to extract stored credentials. Users should update to the latest version immediately.",
    date: "2026-07-02",
    category: "Vulnerability",
    severity: "High"
  },
  {
    id: 4,
    title: "QR Code Scams Surge in Parking Lots",
    summary: "Scammers are placing fake QR code stickers on parking meters across major cities. Scanning these codes leads to fraudulent payment sites that steal credit card information.",
    date: "2026-07-01",
    category: "Scams",
    severity: "Medium"
  },
  {
    id: 5,
    title: "Deepfake Voice Scams Target Businesses",
    summary: "Fraudsters are using AI-generated voice clones of CEOs to authorize fraudulent wire transfers. Companies are advised to implement verification protocols for all financial requests.",
    date: "2026-06-30",
    category: "AI Threats",
    severity: "High"
  },
  {
    id: 6,
    title: "Social Media Platform Patches Data Leak",
    summary: "A popular social media platform has fixed a vulnerability that exposed millions of user email addresses and phone numbers. Users should review their privacy settings and enable 2FA.",
    date: "2026-06-28",
    category: "Data Breach",
    severity: "Medium"
  },
  {
    id: 7,
    title: "New Spyware Targets Mobile Banking Apps",
    summary: "Security researchers have discovered sophisticated spyware specifically designed to intercept mobile banking credentials. The malware spreads through fake banking app updates.",
    date: "2026-06-27",
    category: "Malware",
    severity: "High"
  },
  {
    id: 8,
    title: "Cybersecurity Awareness Month Initiatives Announced",
    summary: "Government agencies and private organizations are launching collaborative cybersecurity education programs aimed at protecting vulnerable populations from online threats.",
    date: "2026-06-25",
    category: "Education",
    severity: "Low"
  },
  {
    id: 9,
    title: "Crypto Wallet Draining Scams on the Rise",
    summary: "Scammers are using fake customer support accounts on social media to trick cryptocurrency holders into revealing seed phrases, draining wallets within minutes.",
    date: "2026-06-24",
    category: "Scams",
    severity: "Medium"
  },
  {
    id: 10,
    title: "Smart Home Device Vulnerabilities Exposed",
    summary: "A security audit of popular smart home devices found multiple vulnerabilities that could allow hackers to access home networks. Manufacturers are releasing firmware updates.",
    date: "2026-06-22",
    category: "IoT",
    severity: "Medium"
  }
];
