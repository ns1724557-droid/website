export interface Threat {
  id: string;
  title: string;
  description: string;
  signs: string[];
  prevention: string[];
  image?: string;
  icon: string;
}

export const threats: Threat[] = [
  {
    id: "phishing",
    title: "Phishing",
    description: "Phishing is a cyberattack that uses disguised email, text messages, or websites to trick victims into revealing sensitive information like passwords, credit card numbers, or personal data.",
    signs: [
      "Urgent or threatening language demanding immediate action",
      "Requests for personal information, passwords, or PINs",
      "Suspicious sender email addresses with typos",
      "Generic greetings like 'Dear Customer' instead of your name",
      "Links that don't match the displayed text when hovered"
    ],
    prevention: [
      "Never click links in unsolicited emails",
      "Verify sender identity before responding",
      "Check URLs carefully before entering credentials",
      "Use email filters and anti-phishing browser extensions",
      "Enable multi-factor authentication on all accounts"
    ],
    image: "/threat_phishing.jpg",
    icon: "MailWarning"
  },
  {
    id: "malware",
    title: "Malware",
    description: "Malware (malicious software) is any program designed to harm, exploit, or gain unauthorized access to computer systems. Types include viruses, worms, trojans, and spyware.",
    signs: [
      "Computer running unusually slow",
      "Frequent crashes or freezes",
      "Unexpected pop-up ads appearing",
      "Programs opening or closing automatically",
      "Unknown processes running in task manager"
    ],
    prevention: [
      "Install reputable antivirus software and keep it updated",
      "Avoid downloading files from untrusted sources",
      "Keep operating system and applications patched",
      "Don't click on suspicious ads or pop-ups",
      "Regularly scan your system for threats"
    ],
    image: "/threat_malware.jpg",
    icon: "Bug"
  },
  {
    id: "ransomware",
    title: "Ransomware",
    description: "Ransomware is malware that encrypts victims' files, demanding payment (ransom) for the decryption key. It can paralyze businesses and destroy personal data permanently.",
    signs: [
      "Files won't open and have strange extensions",
      "Ransom note displayed on screen",
      "Desktop wallpaper changed to ransom message",
      "Unable to access folders or applications",
      "Demands for cryptocurrency payment"
    ],
    prevention: [
      "Maintain regular offline backups (3-2-1 rule)",
      "Keep all software updated with security patches",
      "Use email filtering to block malicious attachments",
      "Segment networks to limit spread",
      "Never pay the ransom — it encourages attackers"
    ],
    image: "/threat_malware.jpg",
    icon: "Lock"
  },
  {
    id: "spyware",
    title: "Spyware",
    description: "Spyware secretly monitors user activity, collecting keystrokes, browsing habits, passwords, and personal information without consent.",
    signs: [
      "Browser homepage changed without permission",
      "New toolbars or extensions you didn't install",
      "Excessive internet data usage",
      "Antivirus software disabled automatically",
      "Computer performance degraded significantly"
    ],
    prevention: [
      "Download software only from official sources",
      "Read permissions before installing apps",
      "Use anti-spyware tools alongside antivirus",
      "Avoid 'free' software from unknown vendors",
      "Regularly review installed programs and browser extensions"
    ],
    image: "/detect_response_laptop.jpg",
    icon: "Eye"
  },
  {
    id: "identity-theft",
    title: "Identity Theft",
    description: "Identity theft occurs when someone steals your personal information to commit fraud, such as opening accounts, making purchases, or filing taxes in your name.",
    signs: [
      "Unfamiliar accounts on credit report",
      "Bills for services you didn't use",
      "Calls from debt collectors for unknown debts",
      "Missing mail or statements",
      "Social media accounts hacked"
    ],
    prevention: [
      "Shred documents containing personal information",
      "Monitor credit reports regularly",
      "Use strong, unique passwords for all accounts",
      "Enable account alerts for suspicious activity",
      "Freeze credit when not actively applying for loans"
    ],
    image: "/threat_identity.jpg",
    icon: "UserX"
  },
  {
    id: "cyberbullying",
    title: "Cyberbullying",
    description: "Cyberbullying involves using digital platforms to harass, threaten, or intimidate others. It can cause severe emotional distress and mental health issues.",
    signs: [
      "Receiving threatening or hurtful messages",
      "Spreading rumors or embarrassing photos online",
      "Being excluded from online groups deliberately",
      "Impersonation to damage reputation",
      "Persistent unwanted contact after being asked to stop"
    ],
    prevention: [
      "Don't respond to bullying messages",
      "Save evidence (screenshots) of harassment",
      "Block and report the bully on platforms",
      "Talk to trusted adults or counselors",
      "Adjust privacy settings to limit who can contact you"
    ],
    image: "/education_hero.jpg",
    icon: "MessageSquareWarning"
  },
  {
    id: "online-scams",
    title: "Online Scams",
    description: "Online scams use deceptive tactics to steal money or information. Common types include lottery scams, romance scams, investment fraud, and fake tech support.",
    signs: [
      "Promises of unrealistic returns or winnings",
      "Requests for upfront fees or payments",
      "Pressure to act immediately",
      "Requests to pay via gift cards or wire transfers",
      "Refusal to provide written documentation"
    ],
    prevention: [
      "If it sounds too good to be true, it probably is",
      "Research companies and offers thoroughly",
      "Never send money to someone you haven't met",
      "Verify claims independently through official channels",
      "Report suspected scams to authorities immediately"
    ],
    image: "/threat_phishing.jpg",
    icon: "AlertTriangle"
  },
  {
    id: "qr-code-scams",
    title: "QR Code Scams",
    description: "Scammers place malicious QR codes over legitimate ones (quishing). Scanning redirects to phishing sites, initiates unauthorized payments, or downloads malware.",
    signs: [
      "QR codes placed over existing codes in public places",
      "URLs from QR scans that look suspicious",
      "Requests for payment after scanning",
      "Downloads starting automatically after scan",
      "URLs with misspelled domain names"
    ],
    prevention: [
      "Inspect QR codes for stickers placed over originals",
      "Use QR scanners that preview URLs before opening",
      "Never enter credentials after scanning unknown QR codes",
      "Verify payment requests independently",
      "Be especially cautious with QR codes in public spaces"
    ],
    image: "/threat_phishing.jpg",
    icon: "QrCode"
  },
  {
    id: "ai-scams",
    title: "AI-Powered Scams",
    description: "AI enables sophisticated scams including voice cloning, deepfake videos, and automated phishing that can convincingly impersonate trusted individuals.",
    signs: [
      "Calls from 'family members' asking for emergency money",
      "Video calls where the person seems slightly off",
      "Messages mimicking your writing style perfectly",
      "Requests for verification codes 'sent by mistake'",
      "AI-generated images promoting fake products"
    ],
    prevention: [
      "Establish a family code word for emergencies",
      "Verify unusual requests through a different channel",
      "Don't share verification codes with anyone",
      "Look for inconsistencies in video calls (lighting, lip sync)",
      "Be skeptical of perfect-sounding voice messages asking for money"
    ],
    image: "/threat_identity.jpg",
    icon: "Bot"
  },
  {
    id: "deepfake-fraud",
    title: "Deepfake Fraud",
    description: "Deepfakes use AI to create hyper-realistic fake videos and audio, enabling fraud, misinformation, and reputational damage at unprecedented scale.",
    signs: [
      "Videos with unnatural blinking or facial movements",
      "Audio that doesn't match lip movements",
      "Unusual lighting inconsistencies on faces",
      "Content that seems out of character for the person",
      "Urgent requests in video format from executives"
    ],
    prevention: [
      "Verify shocking videos through multiple sources",
      "Use deepfake detection tools when available",
      "Establish verification protocols for financial requests",
      "Be extra cautious with video-based instructions",
      "Report suspected deepfakes to platforms immediately"
    ],
    image: "/threat_identity.jpg",
    icon: "Video"
  }
];
