import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Shield, Menu, X, Search, MessageSquare, Lock,
  FileQuestion, Home, Siren, Phone,
  ClipboardCheck, Newspaper, Type
} from 'lucide-react';

interface NavbarProps {
  largeText: boolean;
  toggleLargeText: () => void;
}

export default function Navbar({ largeText, toggleLargeText }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  const navLinks = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/threats', label: 'Threats', icon: Shield },
    { to: '/quiz', label: 'Quiz', icon: ClipboardCheck },
    { to: '/assistant', label: 'AI Assistant', icon: MessageSquare },
    { to: '/password-tools', label: 'Password Tools', icon: Lock },
    { to: '/phishing-detector', label: 'Phishing', icon: Search },
    { to: '/url-checker', label: 'URL Checker', icon: Shield },
    { to: '/news', label: 'News', icon: Newspaper },
    { to: '/faq', label: 'FAQ', icon: FileQuestion },
    { to: '/report', label: 'Report', icon: Siren },
    { to: '/contact', label: 'Contact', icon: Phone },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#0B0F17]/90 backdrop-blur-xl border-b border-white/10'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <Shield className="w-7 h-7 text-[#00E5C0] group-hover:scale-110 transition-transform" />
              <span className="text-lg font-semibold text-white tracking-tight">
                SafeNet <span className="text-[#00E5C0]">Haven</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.slice(0, 7).map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`nav-link px-3 py-2 rounded-lg transition-all ${
                    location.pathname === link.to
                      ? 'text-[#00E5C0] bg-[#00E5C0]/10'
                      : ''
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-2">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 rounded-lg text-[var(--text-secondary)] hover:text-white hover:bg-white/10 transition-all"
                aria-label="Search"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Large Text Toggle */}
              <button
                onClick={toggleLargeText}
                className={`p-2 rounded-lg transition-all ${
                  largeText ? 'text-[#00E5C0] bg-[#00E5C0]/10' : 'text-[var(--text-secondary)] hover:text-white hover:bg-white/10'
                }`}
                aria-label="Toggle large text"
                title="Large Text Mode"
              >
                <Type className="w-5 h-5" />
              </button>

              {/* Mobile menu */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="lg:hidden p-2 rounded-lg text-[var(--text-secondary)] hover:text-white hover:bg-white/10 transition-all"
                aria-label="Menu"
              >
                {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Search overlay */}
        {searchOpen && (
          <div className="absolute top-full left-0 right-0 bg-[#0B0F17]/95 backdrop-blur-xl border-b border-white/10 p-4 animate-fade-in">
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search threats, tips, FAQs..."
                  className="input-cyber pl-12 pr-4 py-3"
                  autoFocus
                />
              </div>
            </form>
          </div>
        )}
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-72 bg-[#121A26] border-l border-white/10 p-6 overflow-y-auto animate-slide-up">
            <div className="flex items-center justify-between mb-8">
              <span className="text-lg font-semibold text-white">Menu</span>
              <button onClick={() => setMobileOpen(false)} className="p-2 rounded-lg hover:bg-white/10">
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    location.pathname === link.to
                      ? 'text-[#00E5C0] bg-[#00E5C0]/10'
                      : 'text-[var(--text-secondary)] hover:text-white hover:bg-white/10'
                  }`}
                >
                  <link.icon className="w-5 h-5" />
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
