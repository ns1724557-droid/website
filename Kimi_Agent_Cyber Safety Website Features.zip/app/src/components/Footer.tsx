import { Link } from 'react-router-dom';
import { Shield, Github, Twitter, Linkedin, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative z-10 bg-[#121A26] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <Shield className="w-6 h-6 text-[#00E5C0]" />
              <span className="text-lg font-semibold text-white">
                SafeNet <span className="text-[#00E5C0]">Haven</span>
              </span>
            </Link>
            <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
              Empowering individuals and organizations with cybersecurity awareness, tools, and education to stay safe in the digital world.
            </p>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Resources</h4>
            <ul className="space-y-2">
              {[
                { to: '/threats', label: 'Threat Library' },
                { to: '/quiz', label: 'Cyber Safety Quiz' },
                { to: '/password-tools', label: 'Password Tools' },
                { to: '/phishing-detector', label: 'Phishing Detector' },
                { to: '/faq', label: 'FAQ' },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm text-[var(--text-secondary)] hover:text-[#00E5C0] transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2">
              {[
                { to: '/assistant', label: 'AI Assistant' },
                { to: '/news', label: 'Latest News' },
                { to: '/report', label: 'Report Crime' },
                { to: '/contact', label: 'Contact Us' },
                { to: '/pledge', label: 'Take the Pledge' },
              ].map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm text-[var(--text-secondary)] hover:text-[#00E5C0] transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                <Mail className="w-4 h-4 text-[#00E5C0]" />
                report@safenethaven.org
              </li>
              <li className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                <Shield className="w-4 h-4 text-[#00E5C0]" />
                1-800-SAFENET
              </li>
            </ul>
            <div className="flex items-center gap-3 mt-4">
              {[
                { icon: Twitter, label: 'Twitter' },
                { icon: Linkedin, label: 'LinkedIn' },
                { icon: Github, label: 'GitHub' },
              ].map(({ icon: Icon, label }) => (
                <button
                  key={label}
                  className="p-2 rounded-lg bg-white/5 text-[var(--text-secondary)] hover:text-[#00E5C0] hover:bg-white/10 transition-all"
                  aria-label={label}
                >
                  <Icon className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[var(--text-secondary)]">
            &copy; {new Date().getFullYear()} SafeNet Haven. Built for public awareness.
          </p>
          <div className="flex items-center gap-4 text-xs text-[var(--text-secondary)]">
            <Link to="/faq" className="hover:text-[#00E5C0] transition-colors">Privacy</Link>
            <Link to="/faq" className="hover:text-[#00E5C0] transition-colors">Terms</Link>
            <Link to="/faq" className="hover:text-[#00E5C0] transition-colors">Accessibility</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
