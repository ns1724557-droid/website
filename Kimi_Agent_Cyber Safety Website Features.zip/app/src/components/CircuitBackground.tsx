import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
}

export default function CircuitBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: -1000, y: -1000 });
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };
    resize();

    // Initialize particles
    const particleCount = Math.min(35, Math.floor((width * height) / 40000));
    particlesRef.current = Array.from({ length: particleCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      size: Math.random() * 2 + 1,
      opacity: Math.random() * 0.4 + 0.3,
    }));

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
    };

    const drawCircuit = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw topographic contour lines
      const time = Date.now() * 0.0001;
      ctx.strokeStyle = 'rgba(0, 229, 192, 0.12)';
      ctx.lineWidth = 1;

      for (let i = 0; i < 8; i++) {
        ctx.beginPath();
        const offsetY = (i / 8) * height * 1.5 - height * 0.25;
        for (let x = 0; x <= width; x += 5) {
          const y = offsetY + Math.sin(x * 0.003 + time + i * 0.7) * 60 +
            Math.sin(x * 0.007 + time * 1.3 + i) * 30 +
            Math.sin(x * 0.001 + time * 0.5) * 40;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

      // Draw circuit traces
      const nodes: { x: number; y: number }[] = [];
      const gridSize = 80;
      for (let x = gridSize; x < width; x += gridSize) {
        for (let y = gridSize; y < height; y += gridSize) {
          const jitterX = (Math.sin(x * y * 0.001 + time) * 15);
          const jitterY = (Math.cos(x * y * 0.001 + time * 0.8) * 15);
          nodes.push({ x: x + jitterX, y: y + jitterY });
        }
      }

      // Draw connections
      ctx.strokeStyle = 'rgba(0, 229, 192, 0.2)';
      ctx.lineWidth = 1;
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        // Connect to nearest neighbors
        for (let j = i + 1; j < nodes.length; j++) {
          const other = nodes[j];
          const dist = Math.hypot(node.x - other.x, node.y - other.y);
          if (dist < gridSize * 1.5) {
            const mouseDist = Math.hypot(mouseRef.current.x - (node.x + other.x) / 2, mouseRef.current.y - (node.y + other.y) / 2);
            const highlight = mouseDist < 200 ? 0.6 : 0.2;
            ctx.strokeStyle = `rgba(0, 229, 192, ${highlight})`;
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            // Orthogonal routing (circuit style)
            const midX = (node.x + other.x) / 2;
            ctx.lineTo(midX, node.y);
            ctx.lineTo(midX, other.y);
            ctx.lineTo(other.x, other.y);
            ctx.stroke();
          }
        }
      }

      // Draw nodes
      for (const node of nodes) {
        const mouseDist = Math.hypot(mouseRef.current.x - node.x, mouseRef.current.y - node.y);
        const isHighlighted = mouseDist < 150;
        const radius = isHighlighted ? 4 : 2.5;
        const glow = isHighlighted ? 0.9 : 0.5;

        ctx.beginPath();
        ctx.arc(node.x, node.y, radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 229, 192, ${glow})`;
        ctx.fill();

        if (isHighlighted) {
          ctx.beginPath();
          ctx.arc(node.x, node.y, radius + 6, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(0, 229, 192, 0.15)`;
          ctx.fill();
        }
      }

      // Draw particles
      for (const p of particlesRef.current) {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 229, 192, ${p.opacity})`;
        ctx.fill();
      }

      frameRef.current = requestAnimationFrame(drawCircuit);
    };

    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', handleMouseMove);
    drawCircuit();

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(frameRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}
