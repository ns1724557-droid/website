import { Routes, Route } from 'react-router-dom';
import { useState, useEffect } from 'react';
import CircuitBackground from './components/CircuitBackground';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import AIAssistant from './pages/AIAssistant';
import PasswordTools from './pages/PasswordTools';
import PhishingDetector from './pages/PhishingDetector';
import URLChecker from './pages/URLChecker';
import Quiz from './pages/Quiz';
import ThreatLibrary from './pages/ThreatLibrary';
import ReportCrime from './pages/ReportCrime';
import Contact from './pages/Contact';
import FAQ from './pages/FAQ';
import News from './pages/News';
import Pledge from './pages/Pledge';
import SearchPage from './pages/Search';

export default function App() {
  const [largeText, setLargeText] = useState(false);

  useEffect(() => {
    if (largeText) {
      document.documentElement.style.fontSize = '18px';
    } else {
      document.documentElement.style.fontSize = '';
    }
  }, [largeText]);

  return (
    <div className={`min-h-screen bg-[#0B0F17] text-white relative ${largeText ? 'text-lg' : ''}`}>
      <CircuitBackground />
      <Navbar largeText={largeText} toggleLargeText={() => setLargeText(!largeText)} />
      <main className="relative z-10">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/assistant" element={<AIAssistant />} />
          <Route path="/password-tools" element={<PasswordTools />} />
          <Route path="/phishing-detector" element={<PhishingDetector />} />
          <Route path="/url-checker" element={<URLChecker />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/threats" element={<ThreatLibrary />} />
          <Route path="/report" element={<ReportCrime />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/news" element={<News />} />
          <Route path="/pledge" element={<Pledge />} />
          <Route path="/search" element={<SearchPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
