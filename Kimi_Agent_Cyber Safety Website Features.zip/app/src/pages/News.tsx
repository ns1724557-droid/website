import { useState } from 'react';
import { Newspaper, Calendar, AlertTriangle, Filter } from 'lucide-react';
import { newsData } from '../data/news';

const categories = ['All', 'Ransomware', 'Phishing', 'Malware', 'Data Breach', 'Scams', 'AI Threats', 'Vulnerability', 'IoT', 'Education'];

export default function News() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedNews, setSelectedNews] = useState<number | null>(null);

  const filtered = activeCategory === 'All'
    ? newsData
    : newsData.filter((n) => n.category === activeCategory);

  void selectedNews;

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <Newspaper className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">Cyber News</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Latest Cyber <span className="text-gradient">Threats</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Stay informed about the latest cybersecurity threats, data breaches, and security updates from around the world.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                activeCategory === cat
                  ? 'bg-[#00E5C0] text-[#0B0F17]'
                  : 'bg-white/5 text-[var(--text-secondary)] hover:bg-white/10 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* News Grid */}
        <div className="grid md:grid-cols-2 gap-4">
          {filtered.map((news) => (
            <button
              key={news.id}
              onClick={() => setSelectedNews(selectedNews === news.id ? null : news.id)}
              className={`glass-card glass-card-hover p-5 text-left transition-all ${
                selectedNews === news.id ? 'ring-1 ring-[#00E5C0]/30' : ''
              }`}
            >
              <div className="flex items-center gap-2 mb-3">
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  news.severity === 'High'
                    ? 'bg-red-500/20 text-red-400'
                    : news.severity === 'Medium'
                    ? 'bg-yellow-500/20 text-yellow-400'
                    : 'bg-green-500/20 text-green-400'
                }`}>
                  {news.severity}
                </span>
                <span className="text-xs text-[var(--text-secondary)]">{news.category}</span>
                <span className="text-xs text-[var(--text-secondary)] ml-auto flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {news.date}
                </span>
              </div>
              <h3 className="text-white font-medium mb-2 group-hover:text-[#00E5C0] transition-colors">
                {news.title}
              </h3>
              <p className={`text-sm text-[var(--text-secondary)] leading-relaxed ${
                selectedNews === news.id ? '' : 'line-clamp-2'
              }`}>
                {news.summary}
              </p>
              {selectedNews === news.id && (
                <div className="mt-4 pt-4 border-t border-white/10 animate-fade-in">
                  <div className="flex items-start gap-2 text-sm text-yellow-400">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>Stay vigilant and ensure your security measures are up to date.</span>
                  </div>
                </div>
              )}
            </button>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <Filter className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-4" />
            <p className="text-[var(--text-secondary)]">No news in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
