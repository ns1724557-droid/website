import { useState, useEffect, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search, X, FileQuestion, Lightbulb, AlertTriangle, Newspaper, BookOpen } from 'lucide-react';
import { threats } from '../data/threats';
import { faqData } from '../data/faq';
import { dailyTips } from '../data/tips';
import { newsData } from '../data/news';

interface SearchResult {
  id: string;
  title: string;
  snippet: string;
  type: string;
  link: string;
  icon: React.ElementType;
}

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQuery);

  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    const allResults: SearchResult[] = [];

    // Search threats
    threats.forEach((t) => {
      if (t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)) {
        allResults.push({
          id: `threat-${t.id}`,
          title: t.title,
          snippet: t.description.slice(0, 120) + '...',
          type: 'Threat',
          link: `/threats`,
          icon: AlertTriangle,
        });
      }
    });

    // Search FAQ
    faqData.forEach((f) => {
      if (f.question.toLowerCase().includes(q) || f.answer.toLowerCase().includes(q)) {
        allResults.push({
          id: `faq-${f.id}`,
          title: f.question,
          snippet: f.answer.slice(0, 120) + '...',
          type: 'FAQ',
          link: `/faq`,
          icon: FileQuestion,
        });
      }
    });

    // Search tips
    dailyTips.forEach((t, i) => {
      if (t.title.toLowerCase().includes(q) || t.content.toLowerCase().includes(q)) {
        allResults.push({
          id: `tip-${i}`,
          title: t.title,
          snippet: t.content.slice(0, 120) + '...',
          type: 'Tip',
          link: `/`,
          icon: Lightbulb,
        });
      }
    });

    // Search news
    newsData.forEach((n) => {
      if (n.title.toLowerCase().includes(q) || n.summary.toLowerCase().includes(q)) {
        allResults.push({
          id: `news-${n.id}`,
          title: n.title,
          snippet: n.summary.slice(0, 120) + '...',
          type: 'News',
          link: `/news`,
          icon: Newspaper,
        });
      }
    });

    return allResults;
  }, [query]);

  const grouped = useMemo(() => {
    const groups: Record<string, SearchResult[]> = {};
    results.forEach((r) => {
      if (!groups[r.type]) groups[r.type] = [];
      groups[r.type].push(r);
    });
    return groups;
  }, [results]);

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            Search <span className="text-gradient">Results</span>
          </h1>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search..."
              className="input-cyber pl-12 pr-10"
              autoFocus
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-white/10"
              >
                <X className="w-4 h-4 text-[var(--text-secondary)]" />
              </button>
            )}
          </div>
        </div>

        {/* Results */}
        {query.trim() && (
          <>
            <p className="text-sm text-[var(--text-secondary)] mb-6">
              Found {results.length} result{results.length !== 1 ? 's' : ''} for &quot;{query}&quot;
            </p>

            {Object.entries(grouped).map(([type, items]) => (
              <div key={type} className="mb-8">
                <h2 className="text-sm font-medium text-[#00E5C0] uppercase tracking-wider mb-3">
                  {type} ({items.length})
                </h2>
                <div className="space-y-3">
                  {items.map((result) => (
                    <Link
                      key={result.id}
                      to={result.link}
                      className="glass-card glass-card-hover p-4 flex items-start gap-4 group"
                    >
                      <div className="p-2 rounded-lg bg-[#00E5C0]/10 shrink-0">
                        <result.icon className="w-5 h-5 text-[#00E5C0]" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-white font-medium mb-1 group-hover:text-[#00E5C0] transition-colors">
                          {result.title}
                        </h3>
                        <p className="text-sm text-[var(--text-secondary)] line-clamp-2">{result.snippet}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            ))}

            {results.length === 0 && (
              <div className="text-center py-16">
                <Search className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-4" />
                <p className="text-[var(--text-secondary)] mb-2">No results found.</p>
                <p className="text-sm text-[var(--text-secondary)]">
                  Try searching for: password, phishing, malware, 2FA, ransomware, or VPN
                </p>
              </div>
            )}
          </>
        )}

        {!query.trim() && (
          <div className="text-center py-16">
            <BookOpen className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-4" />
            <p className="text-[var(--text-secondary)]">Enter a search term to find content across the site.</p>
          </div>
        )}
      </div>
    </div>
  );
}
