import { useState } from 'react';
import {
  Shield, AlertTriangle, Lock, Bug, Eye, UserX,
  MessageSquareWarning, QrCode, Bot, Video, ChevronRight, Search, X
} from 'lucide-react';
import { threats } from '../data/threats';

const iconMap: Record<string, React.ElementType> = {
  MailWarning: AlertTriangle,
  Bug: Bug,
  Lock: Lock,
  Eye: Eye,
  UserX: UserX,
  MessageSquareWarning: MessageSquareWarning,
  AlertTriangle: AlertTriangle,
  QrCode: QrCode,
  Bot: Bot,
  Video: Video,
};

export default function ThreatLibrary() {
  const [selectedThreat, setSelectedThreat] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredThreats = threats.filter((t) =>
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selected = threats.find((t) => t.id === selectedThreat);

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <Shield className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">Threat Library</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Cyber Threat <span className="text-gradient">Library</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Comprehensive guide to understanding different types of cyber threats and how to protect yourself against them.
          </p>
        </div>

        {/* Search */}
        <div className="relative max-w-lg mx-auto mb-10">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search threats..."
            className="input-cyber pl-12 pr-10"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-white/10"
            >
              <X className="w-4 h-4 text-[var(--text-secondary)]" />
            </button>
          )}
        </div>

        {/* Threat Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
          {filteredThreats.map((threat) => {
            const Icon = iconMap[threat.icon] || Shield;
            return (
              <button
                key={threat.id}
                onClick={() => setSelectedThreat(selectedThreat === threat.id ? null : threat.id)}
                className={`glass-card glass-card-hover p-6 text-left transition-all ${
                  selectedThreat === threat.id ? 'ring-1 ring-[#00E5C0]/40' : ''
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-[#00E5C0]/10 shrink-0">
                    <Icon className="w-6 h-6 text-[#00E5C0]" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-lg font-semibold text-white mb-1">{threat.title}</h3>
                    <p className="text-sm text-[var(--text-secondary)] line-clamp-2">{threat.description}</p>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-1 text-[#00E5C0] text-sm">
                  <span>Learn more</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Detail View */}
        {selected && (
          <div className="glass-card p-6 lg:p-8 animate-fade-in">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-[#00E5C0]/10">
                  <Shield className="w-8 h-8 text-[#00E5C0]" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">{selected.title}</h2>
                </div>
              </div>
              <button
                onClick={() => setSelectedThreat(null)}
                className="p-2 rounded-lg hover:bg-white/10 text-[var(--text-secondary)]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-[var(--text-secondary)] leading-relaxed mb-8">{selected.description}</p>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Warning Signs */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-500" />
                  Warning Signs
                </h3>
                <ul className="space-y-3">
                  {selected.signs.map((sign, i) => (
                    <li key={i} className="flex items-start gap-3 p-3 rounded-lg bg-red-500/5 border border-red-500/10">
                      <span className="w-5 h-5 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span className="text-sm text-white/80">{sign}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Prevention */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#00E5C0]" />
                  Prevention Tips
                </h3>
                <ul className="space-y-3">
                  {selected.prevention.map((tip, i) => (
                    <li key={i} className="flex items-start gap-3 p-3 rounded-lg bg-[#00E5C0]/5 border border-[#00E5C0]/10">
                      <span className="w-5 h-5 rounded-full bg-[#00E5C0]/20 text-[#00E5C0] flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span className="text-sm text-white/80">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {filteredThreats.length === 0 && (
          <div className="text-center py-16">
            <Search className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-4" />
            <p className="text-[var(--text-secondary)]">No threats found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}
