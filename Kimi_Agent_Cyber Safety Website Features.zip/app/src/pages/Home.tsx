import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Shield, ArrowRight, AlertTriangle, Lock, UserX,
  Lightbulb, ChevronRight, TrendingUp,
  Zap, Globe, Eye
} from 'lucide-react';
import { getDailyTip, dailyTips } from '../data/tips';
import { newsData } from '../data/news';
import StatCard from '../components/StatCard';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const heroCardRef = useRef<HTMLDivElement>(null);
  const heroTextRef = useRef<HTMLDivElement>(null);
  const [dailyTip, setDailyTip] = useState(getDailyTip());
  const [tipIndex, setTipIndex] = useState(0);

  useEffect(() => {
    // Hero load animation
    const tl = gsap.timeline({ delay: 0.2 });
    tl.fromTo(
      heroCardRef.current,
      { y: 60, opacity: 0, scale: 0.98 },
      { y: 0, opacity: 1, scale: 1, duration: 0.8, ease: 'power2.out' }
    );
    tl.fromTo(
      heroTextRef.current?.querySelectorAll('.hero-anim') || [],
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power2.out' },
      '-=0.4'
    );

    // Scroll animations for sections
    const sections = document.querySelectorAll('.scroll-reveal');
    sections.forEach((section) => {
      gsap.fromTo(
        section,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  const cycleTip = () => {
    const nextIndex = (tipIndex + 1) % dailyTips.length;
    setTipIndex(nextIndex);
    setDailyTip(dailyTips[nextIndex]);
  };

  return (
    <div className="relative z-10">
      {/* Hero Section */}
      <section ref={heroRef} className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 pt-20 pb-10">
        <div
          ref={heroCardRef}
          className="w-full max-w-6xl glass-card overflow-hidden opacity-0"
          style={{ minHeight: '70vh' }}
        >
          <div className="flex flex-col lg:flex-row h-full">
            {/* Hero Image */}
            <div className="lg:w-[58%] relative overflow-hidden" style={{ minHeight: '300px' }}>
              <img
                src="/hero_security_room.jpg"
                alt="Cybersecurity Operations Center"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0B0F17]/80 lg:to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-transparent to-transparent lg:hidden" />
            </div>

            {/* Hero Text Panel */}
            <div
              ref={heroTextRef}
              className="lg:w-[42%] flex flex-col justify-center p-8 lg:p-12 relative"
            >
              <span className="hero-anim mono text-xs uppercase tracking-[0.14em] text-[#00E5C0] mb-4">
                Safe Haven Initiative
              </span>
              <h1 className="hero-anim text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
                Cyber Safety.<br />
                <span className="text-gradient">Simplified.</span>
              </h1>
              <p className="hero-anim text-[var(--text-secondary)] text-base lg:text-lg leading-relaxed mb-8">
                Clear guidance to recognize threats, protect your data, and respond with confidence. Your comprehensive cybersecurity awareness platform.
              </p>
              <div className="hero-anim flex flex-wrap gap-4">
                <Link to="/quiz" className="btn-cyber inline-flex items-center gap-2">
                  Start Learning
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link to="/report" className="btn-outline inline-flex items-center gap-2">
                  Report an Incident
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Statistics */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              The Cyber Threat Landscape
            </h2>
            <p className="text-[var(--text-secondary)] max-w-2xl mx-auto">
              Real-time statistics showing the scale of cyber threats affecting individuals and organizations worldwide.
            </p>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            <StatCard icon={Globe} value={2324} suffix="+" label="Cyber attacks per day" delay={0} />
            <StatCard icon={AlertTriangle} value={3470000000} suffix="" label="Phishing emails sent daily" delay={100} />
            <StatCard icon={Zap} value={560000} suffix="+" label="New malware samples daily" delay={200} />
            <StatCard icon={Eye} value={18000000} suffix="+" label="Records breached in 2025" delay={300} />
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
            Cyber threats aren't abstract. They're <span className="text-gradient">everyday.</span>
          </h2>
          <p className="text-[var(--text-secondary)] text-lg leading-relaxed mb-6">
            From a suspicious link in a message to a fake login page — attacks target normal people. Awareness is the first defense. SafeNet Haven provides the tools, knowledge, and support you need to stay protected.
          </p>
          <p className="mono text-xs uppercase tracking-[0.14em] text-[#00E5C0]">
            1 in 3 small organizations face a phishing attempt each month
          </p>
        </div>
      </section>

      {/* Threat Categories */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-8">Common Threats</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: AlertTriangle,
                title: 'Phishing & Scams',
                desc: 'Fake emails, messages, and calls designed to steal credentials or financial information.',
                link: '/threats',
              },
              {
                icon: Lock,
                title: 'Malware & Ransomware',
                desc: 'Harmful software that locks files, spies on activity, or damages systems.',
                link: '/threats',
              },
              {
                icon: UserX,
                title: 'Identity Theft & Fraud',
                desc: 'Stolen personal information used for financial gain or impersonation.',
                link: '/threats',
              },
            ].map((threat, i) => (
              <Link
                key={i}
                to={threat.link}
                className="glass-card glass-card-hover p-6 lg:p-8 group"
              >
                <div className="p-3 rounded-xl bg-[#00E5C0]/10 w-fit mb-4 group-hover:scale-110 transition-transform">
                  <threat.icon className="w-6 h-6 text-[#00E5C0]" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{threat.title}</h3>
                <p className="text-[var(--text-secondary)] text-sm leading-relaxed mb-4">{threat.desc}</p>
                <span className="inline-flex items-center gap-1 text-[#00E5C0] text-sm font-medium group-hover:gap-2 transition-all">
                  Learn more <ChevronRight className="w-4 h-4" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Prevention Habits */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="glass-card p-8 lg:p-12">
            <div className="grid lg:grid-cols-2 gap-10 items-center">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
                  Prevention is a <span className="text-gradient">habit.</span>
                </h2>
                <p className="text-[var(--text-secondary)] mb-6 leading-relaxed">
                  Small changes in daily behavior dramatically reduce your risk of falling victim to cyberattacks. Start with these fundamental practices.
                </p>
                <Link to="/quiz" className="btn-cyber inline-flex items-center gap-2">
                  Take the Quiz
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {[
                  { icon: Lock, text: 'Use unique passwords + a password manager' },
                  { icon: Shield, text: 'Turn on two-factor authentication' },
                  { icon: Eye, text: 'Verify links before clicking' },
                  { icon: Zap, text: 'Keep software updated' },
                ].map((tip, i) => (
                  <div key={i} className="flex items-start gap-3 p-4 rounded-xl bg-white/5">
                    <tip.icon className="w-5 h-5 text-[#00E5C0] mt-0.5 shrink-0" />
                    <span className="text-sm text-white/90">{tip.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Daily Cyber Tip */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="glass-card p-8 lg:p-10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#00E5C0]/5 rounded-full -translate-y-1/2 translate-x-1/2" />
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[#00E5C0]/10">
                <Lightbulb className="w-5 h-5 text-[#00E5C0]" />
              </div>
              <span className="mono text-xs uppercase tracking-[0.14em] text-[#00E5C0]">
                Daily Cyber Tip
              </span>
              <span className="ml-auto text-xs text-[var(--text-secondary)] bg-white/5 px-3 py-1 rounded-full">
                {dailyTip.category}
              </span>
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">{dailyTip.title}</h3>
            <p className="text-[var(--text-secondary)] leading-relaxed mb-6">{dailyTip.content}</p>
            <button
              onClick={cycleTip}
              className="text-sm text-[#00E5C0] hover:underline inline-flex items-center gap-1"
            >
              Next Tip <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </section>

      {/* Latest News */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Latest Cyber News</h2>
              <p className="text-[var(--text-secondary)]">Stay informed about emerging threats</p>
            </div>
            <Link to="/news" className="hidden sm:inline-flex items-center gap-1 text-[#00E5C0] hover:underline">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {newsData.slice(0, 6).map((news) => (
              <div key={news.id} className="glass-card glass-card-hover p-5 group">
                <div className="flex items-center gap-2 mb-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    news.severity === 'High'
                      ? 'bg-red-500/20 text-red-400'
                      : news.severity === 'Medium'
                      ? 'bg-yellow-500/20 text-yellow-400'
                      : 'bg-green-500/20 text-green-400'
                  }`}>
                    {news.severity}
                  </span>
                  <span className="text-xs text-[var(--text-secondary)]">{news.category}</span>
                </div>
                <h3 className="text-sm font-semibold text-white mb-2 line-clamp-2 group-hover:text-[#00E5C0] transition-colors">
                  {news.title}
                </h3>
                <p className="text-xs text-[var(--text-secondary)] line-clamp-2 mb-3">{news.summary}</p>
                <span className="text-xs text-[var(--text-secondary)]">{news.date}</span>
              </div>
            ))}
          </div>
          <Link to="/news" className="sm:hidden mt-6 inline-flex items-center gap-1 text-[#00E5C0]">
            View all news <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Quick Tools Preview */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-8 text-center">Interactive Tools</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { to: '/assistant', icon: Shield, title: 'AI Assistant', desc: 'Get instant cybersecurity advice' },
              { to: '/password-tools', icon: Lock, title: 'Password Tools', desc: 'Check strength & generate secure passwords' },
              { to: '/phishing-detector', icon: AlertTriangle, title: 'Phishing Detector', desc: 'Learn to identify fake emails' },
              { to: '/quiz', icon: TrendingUp, title: 'Safety Quiz', desc: 'Test your knowledge with 20 questions' },
            ].map((tool) => (
              <Link
                key={tool.to}
                to={tool.to}
                className="glass-card glass-card-hover p-6 text-center group"
              >
                <div className="p-3 rounded-xl bg-[#00E5C0]/10 w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <tool.icon className="w-6 h-6 text-[#00E5C0]" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">{tool.title}</h3>
                <p className="text-sm text-[var(--text-secondary)]">{tool.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="scroll-reveal py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="glass-card p-10 lg:p-14 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-[#00E5C0]/5 to-transparent" />
            <div className="relative z-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                Take the <span className="text-gradient">Cyber Safety Pledge</span>
              </h2>
              <p className="text-[var(--text-secondary)] max-w-xl mx-auto mb-8 leading-relaxed">
                Join thousands of individuals committed to practicing safe online habits. Take our pledge and receive a personalized digital certificate.
              </p>
              <Link to="/pledge" className="btn-cyber inline-flex items-center gap-2">
                Take the Pledge
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
