import { useState, useEffect, useCallback } from 'react';
import { Lock, Copy, Check, RefreshCw, Shield, Eye, EyeOff, Zap } from 'lucide-react';

type Strength = 'empty' | 'weak' | 'fair' | 'good' | 'strong';

function evaluatePassword(password: string): { strength: Strength; score: number; feedback: string[] } {
  if (!password) return { strength: 'empty', score: 0, feedback: ['Start typing to see password strength'] };

  let score = 0;
  const feedback: string[] = [];

  if (password.length >= 12) score += 2;
  else if (password.length >= 8) score += 1;
  else feedback.push('Use at least 12 characters');

  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score += 1;
  else feedback.push('Mix uppercase and lowercase letters');

  if (/\d/.test(password)) score += 1;
  else feedback.push('Add numbers');

  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) score += 1;
  else feedback.push('Add special characters (!@#$...)');

  if (/(.).*\1{2,}/.test(password)) {
    score -= 1;
    feedback.push('Avoid repeating characters');
  }

  if (/(012|123|234|345|456|567|678|789|890|abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz|qwerty|password|admin|login)/i.test(password)) {
    score -= 2;
    feedback.push('Avoid common patterns and sequences');
  }

  const strengthMap: Strength[] = ['weak', 'weak', 'fair', 'good', 'strong', 'strong'];
  const finalStrength = strengthMap[Math.max(0, Math.min(5, score))];

  if (feedback.length === 0) feedback.push('Excellent password!');

  return { strength: finalStrength, score: Math.max(0, score), feedback };
}

export default function PasswordTools() {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState(false);
  const [generated, setGenerated] = useState('');
  [generated];
  const [genLength, setGenLength] = useState(16);
  const [includeUpper, setIncludeUpper] = useState(true);
  const [includeLower, setIncludeLower] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const [genCopied, setGenCopied] = useState(false);

  const { strength, feedback } = evaluatePassword(password);

  const strengthConfig: Record<Strength, { color: string; bg: string; label: string; width: string }> = {
    empty: { color: 'text-[var(--text-secondary)]', bg: 'bg-white/10', label: 'Start typing...', width: '0%' },
    weak: { color: 'text-red-400', bg: 'bg-red-500', label: 'Weak', width: '20%' },
    fair: { color: 'text-yellow-400', bg: 'bg-yellow-500', label: 'Fair', width: '45%' },
    good: { color: 'text-blue-400', bg: 'bg-blue-500', label: 'Good', width: '70%' },
    strong: { color: 'text-[#00E5C0]', bg: 'bg-[#00E5C0]', label: 'Strong', width: '100%' },
  };

  const handleGenerate = useCallback(() => {
    let chars = '';
    if (includeLower) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (includeUpper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeNumbers) chars += '0123456789';
    if (includeSymbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';

    if (!chars) chars = 'abcdefghijklmnopqrstuvwxyz';

    let result = '';
    for (let i = 0; i < genLength; i++) {
      result += chars[Math.floor(Math.random() * chars.length)];
    }
    setGenerated(result);
  }, [genLength, includeUpper, includeLower, includeNumbers, includeSymbols]);

  useEffect(() => {
    handleGenerate();
  }, [handleGenerate]);

  const copyToClipboard = (text: string, type: 'check' | 'gen') => {
    navigator.clipboard.writeText(text);
    if (type === 'check') {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } else {
      setGenCopied(true);
      setTimeout(() => setGenCopied(false), 2000);
    }
  };

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <Lock className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">Password Tools</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Password <span className="text-gradient">Security</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Check your password strength and generate secure passwords to protect your accounts.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Password Strength Checker */}
          <div className="glass-card p-6 lg:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[#00E5C0]/10">
                <Shield className="w-5 h-5 text-[#00E5C0]" />
              </div>
              <h2 className="text-xl font-semibold text-white">Strength Checker</h2>
            </div>

            <div className="relative mb-4">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter a password to check..."
                className="input-cyber pr-24"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                <button
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-2 rounded-lg text-[var(--text-secondary)] hover:text-white hover:bg-white/10 transition-all"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                {password && (
                  <button
                    onClick={() => copyToClipboard(password, 'check')}
                    className="p-2 rounded-lg text-[var(--text-secondary)] hover:text-[#00E5C0] hover:bg-white/10 transition-all"
                  >
                    {copied ? <Check className="w-4 h-4 text-[#00E5C0]" /> : <Copy className="w-4 h-4" />}
                  </button>
                )}
              </div>
            </div>

            {/* Strength Meter */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[var(--text-secondary)]">Strength</span>
                <span className={`text-sm font-medium ${strengthConfig[strength].color}`}>
                  {strengthConfig[strength].label}
                </span>
              </div>
              <div className="progress-bar">
                <div
                  className={`progress-bar-fill ${strengthConfig[strength].bg}`}
                  style={{ width: strengthConfig[strength].width }}
                />
              </div>
            </div>

            {/* Feedback */}
            <div className="space-y-2">
              {feedback.map((f, i) => (
                <div key={i} className="flex items-center gap-2 text-sm">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    strength === 'strong' ? 'bg-[#00E5C0]' : 'bg-yellow-500'
                  }`} />
                  <span className="text-[var(--text-secondary)]">{f}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Password Generator */}
          <div className="glass-card p-6 lg:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[#00E5C0]/10">
                <Zap className="w-5 h-5 text-[#00E5C0]" />
              </div>
              <h2 className="text-xl font-semibold text-white">Generator</h2>
            </div>

            {/* Generated Password Display */}
            <div className="relative mb-6">
              <div className="input-cyber font-mono text-sm break-all pr-24 py-4 min-h-[56px] flex items-center">
                {generated}
              </div>
              <button
                onClick={() => copyToClipboard(generated, 'gen')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-lg text-[var(--text-secondary)] hover:text-[#00E5C0] hover:bg-white/10 transition-all"
              >
                {genCopied ? <Check className="w-4 h-4 text-[#00E5C0]" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            {/* Options */}
            <div className="space-y-4 mb-6">
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-2 block">
                  Length: {genLength} characters
                </label>
                <input
                  type="range"
                  min="8"
                  max="32"
                  value={genLength}
                  onChange={(e) => setGenLength(Number(e.target.value))}
                  className="w-full accent-[#00E5C0]"
                />
                <div className="flex justify-between text-xs text-[var(--text-secondary)] mt-1">
                  <span>8</span>
                  <span>20</span>
                  <span>32</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Uppercase (A-Z)', state: includeUpper, set: setIncludeUpper },
                  { label: 'Lowercase (a-z)', state: includeLower, set: setIncludeLower },
                  { label: 'Numbers (0-9)', state: includeNumbers, set: setIncludeNumbers },
                  { label: 'Symbols (!@#...)', state: includeSymbols, set: setIncludeSymbols },
                ].map((opt) => (
                  <label key={opt.label} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={opt.state}
                      onChange={(e) => opt.set(e.target.checked)}
                      className="w-4 h-4 rounded border-white/20 bg-white/5 checked:bg-[#00E5C0] checked:border-[#00E5C0] accent-[#00E5C0]"
                    />
                    <span className="text-sm text-[var(--text-secondary)]">{opt.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <button
              onClick={handleGenerate}
              className="btn-cyber w-full flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Generate New Password
            </button>
          </div>
        </div>

        {/* Tips */}
        <div className="mt-8 glass-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Password Security Tips</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              'Use a unique password for every account',
              'Aim for at least 12-16 characters',
              'Mix letters, numbers, and symbols',
              'Avoid personal information (names, dates)',
              'Use a password manager',
              'Enable two-factor authentication',
            ].map((tip, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-[#00E5C0]/10 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-xs text-[#00E5C0] font-bold">{i + 1}</span>
                </span>
                <span className="text-sm text-[var(--text-secondary)]">{tip}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
