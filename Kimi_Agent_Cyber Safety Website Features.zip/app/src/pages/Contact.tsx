import { useState } from 'react';
import { Mail, Phone, Send, CheckCircle, MessageSquare, Clock } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Invalid email format';
    if (!formData.subject.trim()) newErrors.subject = 'Subject is required';
    if (!formData.message.trim()) newErrors.message = 'Message is required';
    else if (formData.message.length < 10) newErrors.message = 'Message must be at least 10 characters';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setSubmitted(true);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    if (errors[e.target.name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[e.target.name];
        return next;
      });
    }
  };

  if (submitted) {
    return (
      <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8 min-h-screen flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <div className="glass-card p-10">
            <CheckCircle className="w-16 h-16 text-[#00E5C0] mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-white mb-4">Message Sent!</h2>
            <p className="text-[var(--text-secondary)] mb-6">
              Thank you for reaching out. We've received your message and will get back to you within 24-48 hours.
            </p>
            <button
              onClick={() => {
                setSubmitted(false);
                setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
              }}
              className="btn-outline"
            >
              Send Another Message
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <MessageSquare className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">Contact Us</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Get in <span className="text-gradient">Touch</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Have questions about cybersecurity? Need help reporting an incident? We're here to help.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-4">
            <div className="glass-card p-5">
              <div className="p-2 rounded-lg bg-[#00E5C0]/10 w-fit mb-3">
                <Mail className="w-5 h-5 text-[#00E5C0]" />
              </div>
              <h3 className="text-white font-medium mb-1">Email</h3>
              <p className="text-sm text-[var(--text-secondary)]">report@safenethaven.org</p>
              <p className="text-sm text-[var(--text-secondary)]">help@safenethaven.org</p>
            </div>
            <div className="glass-card p-5">
              <div className="p-2 rounded-lg bg-[#00E5C0]/10 w-fit mb-3">
                <Phone className="w-5 h-5 text-[#00E5C0]" />
              </div>
              <h3 className="text-white font-medium mb-1">Phone</h3>
              <p className="text-sm text-[var(--text-secondary)]">1-800-SAFENET</p>
              <p className="text-sm text-[var(--text-secondary)]">Mon-Fri 9AM-6PM EST</p>
            </div>
            <div className="glass-card p-5">
              <div className="p-2 rounded-lg bg-[#00E5C0]/10 w-fit mb-3">
                <Clock className="w-5 h-5 text-[#00E5C0]" />
              </div>
              <h3 className="text-white font-medium mb-1">Response Time</h3>
              <p className="text-sm text-[var(--text-secondary)]">We typically respond within 24-48 hours. For emergencies, please call our hotline directly.</p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="glass-card p-6 lg:p-8">
              <div className="grid sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm text-[var(--text-secondary)] mb-2">Name *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Your name"
                    className={`input-cyber ${errors.name ? 'border-red-500' : ''}`}
                  />
                  {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
                </div>
                <div>
                  <label className="block text-sm text-[var(--text-secondary)] mb-2">Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="your@email.com"
                    className={`input-cyber ${errors.email ? 'border-red-500' : ''}`}
                  />
                  {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm text-[var(--text-secondary)] mb-2">Phone (optional)</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+1 (555) 000-0000"
                    className="input-cyber"
                  />
                </div>
                <div>
                  <label className="block text-sm text-[var(--text-secondary)] mb-2">Subject *</label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className={`input-cyber ${errors.subject ? 'border-red-500' : ''}`}
                  >
                    <option value="">Select a subject</option>
                    <option value="general">General Inquiry</option>
                    <option value="incident">Report an Incident</option>
                    <option value="education">Education Request</option>
                    <option value="partnership">Partnership</option>
                    <option value="feedback">Feedback</option>
                    <option value="other">Other</option>
                  </select>
                  {errors.subject && <p className="text-red-400 text-xs mt-1">{errors.subject}</p>}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm text-[var(--text-secondary)] mb-2">Message *</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Describe your question or concern..."
                  rows={5}
                  className={`input-cyber resize-none ${errors.message ? 'border-red-500' : ''}`}
                />
                {errors.message && <p className="text-red-400 text-xs mt-1">{errors.message}</p>}
              </div>

              <button type="submit" className="btn-cyber w-full flex items-center justify-center gap-2">
                <Send className="w-4 h-4" />
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
