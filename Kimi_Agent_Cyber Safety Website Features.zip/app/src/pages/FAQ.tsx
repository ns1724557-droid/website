import { useState } from 'react';
import { Search, X, ChevronDown, ChevronUp, HelpCircle, MessageSquare } from 'lucide-react';
import { faqData, faqCategories } from '../data/faq';

export default function FAQ() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [openId, setOpenId] = useState<number | null>(null);

  const filtered = faqData.filter((faq) => {
    const matchesSearch =
      !searchQuery ||
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'All' || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <HelpCircle className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">FAQ</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Frequently Asked <span className="text-gradient">Questions</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Find answers to common questions about cybersecurity, online safety, and protecting your digital life.
          </p>
        </div>

        {/* Search */}
        <div className="relative max-w-lg mx-auto mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-secondary)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search questions..."
            className="input-cyber pl-12 pr-10"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-white/10"
            >
              <X className="w-4 h-4 text-[var(--text-secondary)]" />
            </button>
          )}
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {['All', ...faqCategories].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === cat
                  ? 'bg-[#00E5C0] text-[#0B0F17]'
                  : 'bg-white/5 text-[var(--text-secondary)] hover:bg-white/10 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* FAQ Items */}
        <div className="space-y-3">
          {filtered.map((faq) => (
            <div
              key={faq.id}
              className={`glass-card overflow-hidden transition-all ${
                openId === faq.id ? 'ring-1 ring-[#00E5C0]/20' : ''
              }`}
            >
              <button
                onClick={() => setOpenId(openId === faq.id ? null : faq.id)}
                className="w-full p-5 flex items-start gap-4 text-left"
              >
                <div className="p-2 rounded-lg bg-[#00E5C0]/10 shrink-0 mt-0.5">
                  <MessageSquare className="w-4 h-4 text-[#00E5C0]" />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="text-xs text-[#00E5C0] font-medium uppercase tracking-wider">
                    {faq.category}
                  </span>
                  <h3 className="text-white font-medium mt-1">{faq.question}</h3>
                </div>
                {openId === faq.id ? (
                  <ChevronUp className="w-5 h-5 text-[var(--text-secondary)] shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-[var(--text-secondary)] shrink-0" />
                )}
              </button>
              {openId === faq.id && (
                <div className="px-5 pb-5 pl-16 border-t border-white/10 pt-4 animate-fade-in">
                  <p className="text-[var(--text-secondary)] leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <Search className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-4" />
            <p className="text-[var(--text-secondary)]">No questions found matching your search.</p>
            <button
              onClick={() => { setSearchQuery(''); setActiveCategory('All'); }}
              className="text-[#00E5C0] text-sm mt-2 hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
