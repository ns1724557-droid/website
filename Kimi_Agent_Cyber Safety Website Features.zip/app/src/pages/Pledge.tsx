import { useState, useRef } from 'react';
import { Award, Check, Download, Shield, Lock, Eye, BookOpen, Users } from 'lucide-react';

const pledges = [
  { id: 1, text: "I will use strong, unique passwords for every account", icon: Lock },
  { id: 2, text: "I will enable two-factor authentication on all important accounts", icon: Shield },
  { id: 3, text: "I will think before clicking links or opening attachments", icon: Eye },
  { id: 4, text: "I will keep my software and devices updated", icon: BookOpen },
  { id: 5, text: "I will report suspicious activity to help protect others", icon: Users },
];

export default function Pledge() {
  const [checkedPledges, setCheckedPledges] = useState<number[]>([]);
  const [name, setName] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const certificateRef = useRef<HTMLDivElement>(null);

  const togglePledge = (id: number) => {
    setCheckedPledges((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const allChecked = checkedPledges.length === pledges.length;

  const handleSubmit = () => {
    if (allChecked && name.trim()) {
      setSubmitted(true);
    }
  };

  const generateCertificate = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 850;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    const gradient = ctx.createLinearGradient(0, 0, 1200, 850);
    gradient.addColorStop(0, '#0B0F17');
    gradient.addColorStop(1, '#121A26');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1200, 850);

    // Border
    ctx.strokeStyle = '#00E5C0';
    ctx.lineWidth = 4;
    ctx.strokeRect(40, 40, 1120, 770);
    ctx.strokeStyle = 'rgba(0, 229, 192, 0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(55, 55, 1090, 740);

    // Corner decorations
    const drawCorner = (x: number, y: number, rotate: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rotate);
      ctx.strokeStyle = '#00E5C0';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, -20);
      ctx.lineTo(0, 0);
      ctx.lineTo(20, 0);
      ctx.stroke();
      ctx.restore();
    };
    drawCorner(60, 60, 0);
    drawCorner(1140, 60, Math.PI / 2);
    drawCorner(1140, 790, Math.PI);
    drawCorner(60, 790, -Math.PI / 2);

    // Title
    ctx.fillStyle = '#00E5C0';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('CYBER SAFETY PLEDGE', 600, 140);

    ctx.fillStyle = '#A7B3C7';
    ctx.font = '28px Arial';
    ctx.fillText('Certificate of Commitment', 600, 185);

    // Decorative line
    ctx.strokeStyle = '#00E5C0';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(350, 215);
    ctx.lineTo(850, 215);
    ctx.stroke();

    // Body
    ctx.fillStyle = '#F2F5F9';
    ctx.font = '24px Arial';
    ctx.fillText('This certifies that', 600, 280);

    // Name
    ctx.fillStyle = '#00E5C0';
    ctx.font = 'bold 48px Arial';
    ctx.fillText(name, 600, 350);

    ctx.fillStyle = '#F2F5F9';
    ctx.font = '22px Arial';
    ctx.fillText('has pledged to follow safe online practices', 600, 400);
    ctx.fillText('and contribute to a safer digital community.', 600, 435);

    // Pledges
    ctx.fillStyle = '#A7B3C7';
    ctx.font = '18px Arial';
    let yPos = 490;
    pledges.forEach((p) => {
      ctx.fillText(`\u2713 ${p.text}`, 600, yPos);
      yPos += 32;
    });

    // Date
    const date = new Date().toLocaleDateString('en-US', {
      year: 'numeric', month: 'long', day: 'numeric'
    });
    ctx.fillStyle = '#F2F5F9';
    ctx.font = '20px Arial';
    ctx.fillText(`Date: ${date}`, 600, 700);

    // Footer
    ctx.fillStyle = '#00E5C0';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('SafeNet Haven', 600, 750);
    ctx.fillStyle = '#A7B3C7';
    ctx.font = '18px Arial';
    ctx.fillText('Cyber Safety Awareness Initiative', 600, 780);

    const link = document.createElement('a');
    link.download = `cyber-pledge-certificate-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  if (submitted) {
    return (
      <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8 min-h-screen flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center">
          <div ref={certificateRef} className="glass-card p-10 mb-8">
            <Award className="w-16 h-16 text-[#00E5C0] mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-white mb-4">
              Thank You, <span className="text-gradient">{name}</span>!
            </h2>
            <p className="text-[var(--text-secondary)] mb-6 leading-relaxed">
              You've taken the Cyber Safety Pledge and committed to practicing safe online habits. Together, we're building a safer digital world.
            </p>
            <div className="bg-[#00E5C0]/5 border border-[#00E5C0]/20 rounded-xl p-5 mb-6 text-left">
              <h3 className="text-white font-medium mb-3">Your Commitments:</h3>
              <ul className="space-y-2">
                {pledges.map((p) => (
                  <li key={p.id} className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                    <Check className="w-4 h-4 text-[#00E5C0]" />
                    {p.text}
                  </li>
                ))}
              </ul>
            </div>
            <button
              onClick={generateCertificate}
              className="btn-cyber inline-flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Download Certificate
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <Award className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">Cyber Safety Pledge</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Take the <span className="text-gradient">Pledge</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Commit to practicing safe online habits and receive a personalized digital certificate. Together, we can build a safer digital community.
          </p>
        </div>

        {/* Name Input */}
        <div className="glass-card p-6 mb-6">
          <label className="block text-sm text-[var(--text-secondary)] mb-2">
            Your Name (for the certificate)
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your full name"
            className="input-cyber"
          />
        </div>

        {/* Pledges */}
        <div className="glass-card p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            I pledge to:
          </h2>
          <div className="space-y-3">
            {pledges.map((pledge) => {
              const isChecked = checkedPledges.includes(pledge.id);
              return (
                <button
                  key={pledge.id}
                  onClick={() => togglePledge(pledge.id)}
                  className={`w-full flex items-start gap-4 p-4 rounded-xl border transition-all text-left ${
                    isChecked
                      ? 'border-[#00E5C0]/40 bg-[#00E5C0]/10'
                      : 'border-white/10 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                    isChecked
                      ? 'border-[#00E5C0] bg-[#00E5C0]'
                      : 'border-white/30'
                  }`}>
                    {isChecked && <Check className="w-3.5 h-3.5 text-[#0B0F17]" />}
                  </div>
                  <div className="flex items-start gap-3">
                    <pledge.icon className="w-5 h-5 text-[#00E5C0] shrink-0 mt-0.5" />
                    <span className="text-white/90">{pledge.text}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-[var(--text-secondary)]">Progress</span>
            <span className="text-[#00E5C0]">{checkedPledges.length}/{pledges.length}</span>
          </div>
          <div className="progress-bar">
            <div
              className="progress-bar-fill"
              style={{ width: `${(checkedPledges.length / pledges.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!allChecked || !name.trim()}
          className="btn-cyber w-full py-4 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {allChecked && name.trim()
            ? 'Take the Pledge'
            : `Complete all pledges${!name.trim() ? ' and enter your name' : ''}`
          }
        </button>
      </div>
    </div>
  );
}
