import { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, Globe, Lock, XCircle, Info } from 'lucide-react';

interface URLCheck {
  url: string;
  isSafe: boolean;
  issues: string[];
  tips: string[];
}

function analyzeURL(url: string): URLCheck {
  const issues: string[] = [];
  const tips: string[] = [];
  let isSafe = true;

  const lowerUrl = url.toLowerCase().trim();

  // Check for HTTPS
  if (!lowerUrl.startsWith('https://') && lowerUrl.startsWith('http://')) {
    issues.push('Connection is not encrypted (HTTP instead of HTTPS)');
    isSafe = false;
  }

  // Check for suspicious TLDs
  const suspiciousTLDs = ['.tk', '.ml', '.ga', '.cf', '.top', '.xyz', '.click', '.link', '.work'];
  for (const tld of suspiciousTLDs) {
    if (lowerUrl.includes(tld)) {
      issues.push(`Suspicious domain extension (${tld}) commonly used for scams`);
      isSafe = false;
    }
  }

  // Check for URL shorteners
  const shorteners = ['bit.ly', 'tinyurl', 't.co', 'goo.gl', 'ow.ly', 'short.link'];
  for (const short of shorteners) {
    if (lowerUrl.includes(short)) {
      issues.push('URL shortener detected - hides the real destination');
      isSafe = false;
    }
  }

  // Check for IP addresses
  if (/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(lowerUrl)) {
    issues.push('URL uses an IP address instead of a domain name');
    isSafe = false;
  }

  // Check for suspicious keywords
  const suspiciousKeywords = ['login', 'verify', 'account', 'update', 'secure', 'confirm', 'banking'];
  let hasSuspiciousKeyword = false;
  for (const kw of suspiciousKeywords) {
    if (lowerUrl.includes(kw)) {
      hasSuspiciousKeyword = true;
      break;
    }
  }
  if (hasSuspiciousKeyword) {
    tips.push('URL contains sensitive action keywords - verify the domain carefully');
  }

  // Check for @ symbol
  if (lowerUrl.includes('@')) {
    issues.push('URL contains @ symbol - may redirect to a different site');
    isSafe = false;
  }

  // Check for excessive subdomains
  const subdomainCount = (lowerUrl.match(/\./g) || []).length;
  if (subdomainCount > 3) {
    tips.push('Multiple subdomains detected - could be a sign of subdomain takeover');
  }

  // Check for hyphens in domain (common in typosquatting)
  const domainPart = lowerUrl.replace(/^https?:\/\//, '').split('/')[0];
  if (domainPart.includes('-') && domainPart.length > 15) {
    tips.push('Long domain with hyphens - possible typosquatting attempt');
  }

  // Common brand typosquatting checks
  const brandTypos = [
    { brand: 'paypal', typo: 'paypa1' },
    { brand: 'amazon', typo: 'amaz0n' },
    { brand: 'apple', typo: 'app1e' },
    { brand: 'google', typo: 'g00gle' },
    { brand: 'microsoft', typo: 'micr0soft' },
    { brand: 'netflix', typo: 'netfl1x' },
    { brand: 'facebook', typo: 'faceb00k' },
  ];
  for (const { brand, typo } of brandTypos) {
    if (lowerUrl.includes(typo) || (lowerUrl.includes(brand) && !lowerUrl.includes(`.com`) && !lowerUrl.includes(`.org`))) {
      issues.push(`Possible typosquatting of "${brand}" detected`);
      isSafe = false;
    }
  }

  if (issues.length === 0 && tips.length === 0) {
    tips.push('No obvious red flags detected, but always verify the website independently');
  }

  return { url, isSafe, issues, tips };
}

const educationalTips = [
  {
    icon: Lock,
    title: 'HTTPS is Essential',
    desc: 'Always look for the padlock icon and "https://" in the address bar before entering sensitive information.',
  },
  {
    icon: Globe,
    title: 'Check the Domain',
    desc: 'Verify the domain name carefully. Scammers use misspelled versions of real websites (amaz0n.com vs amazon.com).',
  },
  {
    icon: AlertTriangle,
    title: 'Avoid URL Shorteners',
    desc: 'Shortened links (bit.ly, tinyurl) hide the real destination. Use a URL expander service before clicking.',
  },
  {
    icon: Shield,
    title: 'Look for Trust Seals',
    desc: 'Legitimate e-commerce sites display security badges. Click on them to verify they\'re authentic.',
  },
];

export default function URLChecker() {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<URLCheck | null>(null);
  const [checked, setChecked] = useState(false);

  const handleCheck = () => {
    if (!url.trim()) return;
    let checkUrl = url.trim();
    if (!checkUrl.startsWith('http')) {
      checkUrl = 'https://' + checkUrl;
    }
    setResult(analyzeURL(checkUrl));
    setChecked(true);
  };

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <Globe className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">URL Checker</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Fake Website <span className="text-gradient">Detector</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Enter a website URL to analyze it for common signs of phishing and fraudulent websites.
          </p>
        </div>

        {/* URL Input */}
        <div className="glass-card p-6 lg:p-8 mb-8">
          <div className="flex gap-3">
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCheck()}
              placeholder="Enter website URL (e.g., example.com)"
              className="input-cyber flex-1"
            />
            <button
              onClick={handleCheck}
              className="btn-cyber px-6"
            >
              <Shield className="w-5 h-5" />
            </button>
          </div>

          {/* Results */}
          {checked && result && (
            <div className="mt-6 animate-fade-in">
              <div className={`p-4 rounded-xl mb-4 ${
                result.isSafe
                  ? 'bg-green-500/10 border border-green-500/20'
                  : 'bg-red-500/10 border border-red-500/20'
              }`}>
                <div className="flex items-center gap-3">
                  {result.isSafe ? (
                    <CheckCircle className="w-6 h-6 text-green-400" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-400" />
                  )}
                  <div>
                    <h3 className={`font-semibold ${result.isSafe ? 'text-green-400' : 'text-red-400'}`}>
                      {result.isSafe ? 'No Major Red Flags Found' : 'Potential Security Issues Detected'}
                    </h3>
                    <p className="text-sm text-[var(--text-secondary)]">
                      {result.url}
                    </p>
                  </div>
                </div>
              </div>

              {result.issues.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-red-400 mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    Issues Found ({result.issues.length})
                  </h4>
                  <ul className="space-y-2">
                    {result.issues.map((issue, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-red-200 bg-red-500/5 p-3 rounded-lg">
                        <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                        {issue}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {result.tips.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium text-[#00E5C0] mb-2 flex items-center gap-2">
                    <Info className="w-4 h-4" />
                    Recommendations
                  </h4>
                  <ul className="space-y-2">
                    {result.tips.map((tip, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-[var(--text-secondary)] bg-[#00E5C0]/5 p-3 rounded-lg">
                        <CheckCircle className="w-4 h-4 text-[#00E5C0] shrink-0 mt-0.5" />
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Educational Tips */}
        <div className="grid sm:grid-cols-2 gap-4">
          {educationalTips.map((tip, i) => (
            <div key={i} className="glass-card glass-card-hover p-5">
              <div className="p-2 rounded-lg bg-[#00E5C0]/10 w-fit mb-3">
                <tip.icon className="w-5 h-5 text-[#00E5C0]" />
              </div>
              <h3 className="text-white font-medium mb-2">{tip.title}</h3>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{tip.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
