import { useState } from 'react';
import { MailWarning, AlertTriangle, CheckCircle, XCircle, Eye, ChevronDown, ChevronUp, Shield } from 'lucide-react';

interface PhishingExample {
  id: number;
  subject: string;
  sender: string;
  senderReal: string;
  body: string;
  isPhishing: boolean;
  redFlags: string[];
  explanation: string;
}

const examples: PhishingExample[] = [
  {
    id: 1,
    subject: "URGENT: Your Account Will Be Suspended Today!",
    sender: "security@amaz0n-support.com",
    senderReal: "amaz0n-support.com (not amazon.com)",
    body: "Dear Customer,\n\nWe detected unusual activity on your account. Your account will be suspended within 24 hours unless you verify your information immediately.\n\nClick here to verify: http://amzn-verify.info/login\n\nFailure to act will result in permanent account closure.\n\nAmazon Security Team",
    isPhishing: true,
    redFlags: [
      "Urgent threatening language ('suspended today')",
      "Misspelled domain: amaz0n-support.com (zero instead of 'o')",
      "Suspicious link: amzn-verify.info (not amazon.com)",
      "Generic greeting ('Dear Customer')",
      "Threatens consequences to create urgency"
    ],
    explanation: "This is a classic phishing email. The attacker uses urgency to pressure you into clicking without thinking. Always check the sender's full email address and hover over links to see the real URL."
  },
  {
    id: 2,
    subject: "Your Netflix subscription renewal",
    sender: "info@netflix.com",
    senderReal: "netflix.com (legitimate)",
    body: "Hi there,\n\nYour Netflix subscription will renew on July 15, 2026 for $15.49/month.\n\nNo action is required. You can manage your subscription anytime at netflix.com/account.\n\nThanks for being a member!\n\nThe Netflix Team",
    isPhishing: false,
    redFlags: [],
    explanation: "This appears to be a legitimate Netflix notification. It doesn't ask for credentials, doesn't have suspicious links, and uses proper grammar and branding."
  },
  {
    id: 3,
    subject: "Invoice #2847 - Payment Overdue",
    sender: "invoices@paypa1-security.net",
    senderReal: "paypa1-security.net (not paypal.com)",
    body: "Dear User,\n\nA payment of $499.99 has been charged to your account for Bitcoin purchase. If you did not authorize this transaction, call immediately: +1-800-555-0199\n\nTo dispute this charge, please confirm your:\n- Full Name\n- Card Number\n- CVV Code\n- Billing Address\n\nReply urgently to avoid legal action.",
    isPhishing: true,
    redFlags: [
      "Misspelled domain: paypa1-security.net (1 instead of 'l')",
      "Requests sensitive information (CVV, card number)",
      "Threatens legal action",
      "Asks for credit card details via email",
      "Fake phone number for 'verification'"
    ],
    explanation: "This is a dangerous phishing attempt combining fake invoice scams with vishing (voice phishing via phone). Legitimate companies never ask for CVV codes or full card numbers via email."
  },
  {
    id: 4,
    subject: "Team lunch this Friday?",
    sender: "sarah.jones@company.com",
    senderReal: "company.com (internal domain)",
    body: "Hey team,\n\nHope everyone's having a good week!\n\nAnyone up for team lunch this Friday at that new Italian place downtown? Let me know by Thursday so I can make a reservation.\n\nCheers,\nSarah",
    isPhishing: false,
    redFlags: [],
    explanation: "This is a normal internal email. No suspicious links, no requests for sensitive information, natural tone from a known colleague."
  },
  {
    id: 5,
    subject: "You've Won a $1000 Gift Card!",
    sender: "prizes@amazongift-winner.net",
    senderReal: "amazongift-winner.net (not amazon.com)",
    body: "CONGRATULATIONS!!!\n\nYou've been selected as our lucky winner of a $1000 Amazon Gift Card!\n\nTo claim your prize, simply:\n1. Click the link below\n2. Enter your login details\n3. Confirm your shipping address\n\nCLAIM NOW: http://bit.ly/3xAmzPrize\n\nThis offer expires in 2 hours!",
    isPhishing: true,
    redFlags: [
      "Too good to be true offer",
      "Uses URL shortener (bit.ly) to hide real destination",
      "Creates false urgency ('expires in 2 hours')",
      "Asks for login credentials to 'claim prize'",
      "Suspicious sender domain"
    ],
    explanation: "This is a common 'too good to be true' scam. Real companies don't give away $1000 gift cards randomly. Never enter login credentials on unfamiliar sites, especially through shortened links."
  }
];

export default function PhishingDetector() {
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [showFlags, setShowFlags] = useState<Record<number, boolean>>({});

  const toggleFlags = (id: number) => {
    setShowFlags((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <MailWarning className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">Phishing Detector</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Phishing Email <span className="text-gradient">Detector</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Learn to identify phishing emails by examining real examples. Click on each email to analyze it and reveal the red flags.
          </p>
        </div>

        {/* Educational Banner */}
        <div className="glass-card p-6 mb-8">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-[#00E5C0]/10 shrink-0">
              <Shield className="w-6 h-6 text-[#00E5C0]" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">How to Spot a Phishing Email</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                {[
                  'Check the sender address carefully for misspellings',
                  'Hover over links to see the real destination URL',
                  'Watch for urgent or threatening language',
                  'Be suspicious of requests for personal information',
                  'Look for poor grammar and spelling mistakes',
                  'Verify independently before clicking any links',
                ].map((tip, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
                    <span className="text-sm text-[var(--text-secondary)]">{tip}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Email Examples */}
        <div className="space-y-4">
          {examples.map((email) => (
            <div
              key={email.id}
              className={`glass-card overflow-hidden transition-all ${
                selectedId === email.id ? 'ring-1 ring-[#00E5C0]/30' : ''
              }`}
            >
              {/* Email Header */}
              <button
                onClick={() => setSelectedId(selectedId === email.id ? null : email.id)}
                className="w-full p-5 flex items-start gap-4 text-left"
              >
                <div className={`p-2 rounded-lg shrink-0 ${
                  email.isPhishing ? 'bg-red-500/10' : 'bg-green-500/10'
                }`}>
                  {email.isPhishing ? (
                    <XCircle className="w-5 h-5 text-red-400" />
                  ) : (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      email.isPhishing ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'
                    }`}>
                      {email.isPhishing ? 'PHISHING' : 'LEGITIMATE'}
                    </span>
                  </div>
                  <h3 className="text-white font-medium mb-1 truncate">{email.subject}</h3>
                  <p className="text-sm text-[var(--text-secondary)]">
                    From: <span className={email.isPhishing ? 'text-red-400' : 'text-green-400'}>{email.sender}</span>
                  </p>
                </div>
                {selectedId === email.id ? (
                  <ChevronUp className="w-5 h-5 text-[var(--text-secondary)] shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-[var(--text-secondary)] shrink-0" />
                )}
              </button>

              {/* Expanded Content */}
              {selectedId === email.id && (
                <div className="px-5 pb-5 border-t border-white/10 pt-4">
                  {/* Email Body */}
                  <div className="bg-white/5 rounded-xl p-4 mb-4">
                    <div className="flex items-center gap-2 mb-3 pb-3 border-b border-white/10">
                      <Eye className="w-4 h-4 text-[var(--text-secondary)]" />
                      <span className="text-xs text-[var(--text-secondary)] uppercase tracking-wider">Email Content</span>
                    </div>
                    <pre className="text-sm text-white/80 whitespace-pre-wrap font-sans leading-relaxed">
                      {email.body}
                    </pre>
                  </div>

                  {/* Red Flags Toggle */}
                  {email.redFlags.length > 0 && (
                    <button
                      onClick={() => toggleFlags(email.id)}
                      className="flex items-center gap-2 text-sm text-[#00E5C0] mb-3 hover:underline"
                    >
                      <AlertTriangle className="w-4 h-4" />
                      {showFlags[email.id] ? 'Hide' : 'Show'} Red Flags ({email.redFlags.length})
                      {showFlags[email.id] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  )}

                  {showFlags[email.id] && email.redFlags.length > 0 && (
                    <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4 mb-4">
                      <ul className="space-y-2">
                        {email.redFlags.map((flag, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm">
                            <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                            <span className="text-red-200">{flag}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Explanation */}
                  <div className="bg-[#00E5C0]/5 border border-[#00E5C0]/20 rounded-xl p-4">
                    <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                      <span className="text-[#00E5C0] font-medium">Analysis: </span>
                      {email.explanation}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
