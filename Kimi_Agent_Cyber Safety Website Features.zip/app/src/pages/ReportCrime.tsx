import { useState } from 'react';
import {
  Siren, Phone, Mail, Globe, FileText,
  AlertTriangle, Shield, CheckCircle
} from 'lucide-react';

interface ReportingStep {
  title: string;
  description: string;
}

const steps: ReportingStep[] = [
  {
    title: "Document Everything",
    description: "Take screenshots, save emails, and record all details about the incident including dates, times, and what happened."
  },
  {
    title: "Secure Your Accounts",
    description: "Immediately change passwords, enable 2FA, and disconnect compromised devices from the internet."
  },
  {
    title: "Contact Your Bank",
    description: "If financial information was compromised, contact your bank immediately to freeze accounts and dispute fraudulent charges."
  },
  {
    title: "Report to Authorities",
    description: "File a report with local police, IC3 (FBI), or your country's cybercrime unit. Include all documentation."
  },
  {
    title: "Notify Affected Parties",
    description: "If the breach affects others (work, family), notify them so they can take protective measures."
  },
  {
    title: "Monitor and Follow Up",
    description: "Continue monitoring accounts, follow up on reports, and consider identity protection services if needed."
  }
];

const emergencyContacts = [
  {
    icon: Globe,
    title: "IC3 (FBI Internet Crime)",
    value: "ic3.gov",
    description: "Report internet crime to the FBI",
    link: "https://ic3.gov"
  },
  {
    icon: Phone,
    title: "FTC Fraud Report",
    value: "ReportFraud.ftc.gov",
    description: "Report fraud and identity theft",
    link: "https://reportfraud.ftc.gov"
  },
  {
    icon: Mail,
    title: "Anti-Phishing Working Group",
    value: "reportphishing@apwg.org",
    description: "Report phishing emails",
    link: "mailto:reportphishing@apwg.org"
  },
  {
    icon: Shield,
    title: "Identity Theft Report",
    value: "IdentityTheft.gov",
    description: "Federal identity theft reporting",
    link: "https://identitytheft.gov"
  }
];

export default function ReportCrime() {
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const toggleStep = (index: number) => {
    setCompletedSteps((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/10 mb-4">
            <Siren className="w-4 h-4 text-red-400" />
            <span className="text-sm text-red-400 font-medium">Report Cybercrime</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Report a <span className="text-red-400">Cyber Incident</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            If you've been a victim of cybercrime, take action immediately. Reporting helps protect others and increases the chance of recovery.
          </p>
        </div>

        {/* Emergency Banner */}
        <div className="glass-card p-6 mb-8 border-red-500/20 bg-red-500/5">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-red-500/10 shrink-0">
              <AlertTriangle className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Act Quickly</h3>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                Time is critical in cyber incidents. The faster you report, the better the chances of minimizing damage and catching the perpetrators. Don't feel embarrassed — cybercrime affects millions of people every year.
              </p>
            </div>
          </div>
        </div>

        {/* Reporting Steps */}
        <div className="mb-10">
          <h2 className="text-2xl font-bold text-white mb-6">Reporting Guide</h2>
          <div className="space-y-4">
            {steps.map((step, i) => (
              <div
                key={i}
                onClick={() => toggleStep(i)}
                className={`glass-card p-5 cursor-pointer transition-all ${
                  completedSteps.includes(i) ? 'border-green-500/30 bg-green-500/5' : 'glass-card-hover'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all ${
                    completedSteps.includes(i)
                      ? 'bg-green-500 text-white'
                      : 'bg-white/10 text-[var(--text-secondary)]'
                  }`}>
                    {completedSteps.includes(i) ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <span className="text-sm font-bold">{i + 1}</span>
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className={`font-semibold mb-1 ${
                      completedSteps.includes(i) ? 'text-green-400' : 'text-white'
                    }`}>
                      {step.title}
                    </h3>
                    <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Emergency Contacts */}
        <div className="mb-10">
          <h2 className="text-2xl font-bold text-white mb-6">Official Reporting Channels</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {emergencyContacts.map((contact, i) => (
              <a
                key={i}
                href={contact.link}
                target="_blank"
                rel="noopener noreferrer"
                className="glass-card glass-card-hover p-5 group"
              >
                <div className="flex items-start gap-4">
                  <div className="p-2 rounded-lg bg-[#00E5C0]/10 shrink-0">
                    <contact.icon className="w-5 h-5 text-[#00E5C0]" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-white font-medium mb-1">{contact.title}</h3>
                    <p className="text-[#00E5C0] text-sm font-medium mb-1">{contact.value}</p>
                    <p className="text-xs text-[var(--text-secondary)]">{contact.description}</p>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* What to Include */}
        <div className="glass-card p-6 lg:p-8">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#00E5C0]" />
            What to Include in Your Report
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              'Date and time of the incident',
              'Description of what happened',
              'Screenshots of emails, messages, or websites',
              'Sender email addresses or phone numbers',
              'URLs of suspicious websites',
              'Financial transaction details (if applicable)',
              'Any money lost or data compromised',
              'Steps you have already taken',
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-[#00E5C0]/10 text-[#00E5C0] flex items-center justify-center text-xs font-bold shrink-0">
                  {i + 1}
                </span>
                <span className="text-sm text-[var(--text-secondary)]">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
