import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const knowledgeBase: Record<string, string> = {
  password: "Strong passwords are crucial! Use at least 12-16 characters with a mix of uppercase, lowercase, numbers, and symbols. Avoid personal info. Consider using a password manager to generate and store unique passwords for each account.",
  phishing: "Phishing emails often have urgent language, generic greetings, suspicious links, and spelling errors. Never click links in unsolicited emails. Hover to check the actual URL. When in doubt, contact the organization directly through their official website.",
  malware: "Malware includes viruses, trojans, ransomware, and spyware. Protect yourself by: keeping software updated, using reputable antivirus, avoiding downloads from untrusted sources, and not clicking suspicious ads or pop-ups.",
  "2fa": "Two-Factor Authentication (2FA) adds an extra security layer by requiring a second verification method beyond your password. Enable it on all important accounts—email, banking, social media. Use an authenticator app rather than SMS when possible.",
  vpn: "A VPN (Virtual Private Network) encrypts your internet connection, protecting your data from eavesdroppers. It's especially important on public WiFi. Choose a reputable provider with a no-logs policy.",
  ransomware: "Ransomware encrypts your files and demands payment. Prevention: maintain offline backups (3-2-1 rule), keep software updated, use email filtering, and NEVER pay the ransom—it encourages more attacks and doesn't guarantee file recovery.",
  "public wifi": "Public WiFi is generally unsafe for sensitive activities. Avoid banking or entering passwords. If you must use it, use a VPN or your mobile hotspot instead. Attackers can easily intercept data on unsecured networks.",
  "social media": "Protect your social media: use strong unique passwords, enable 2FA, review privacy settings regularly, be cautious about what you share publicly, and don't accept friend requests from strangers. Oversharing helps attackers build profiles for targeted attacks.",
  "identity theft": "If you suspect identity theft: contact your bank immediately, place a fraud alert on credit reports, freeze your credit, file a police report, report to IdentityTheft.gov, change all passwords, and monitor accounts closely.",
  backup: "Follow the 3-2-1 backup rule: keep 3 copies of important data, on 2 different media types (e.g., external drive + cloud), with 1 stored offsite. Test your backups periodically to ensure they're recoverable.",
  "deepfake": "Deepfakes use AI to create convincing fake videos/audio. Warning signs: unnatural blinking, inconsistent lighting, mismatched audio. Verify shocking content through multiple sources. Establish a family code word for emergency verification.",
  "qr code": "QR code scams (quishing) involve placing malicious codes over legitimate ones. Always inspect QR codes for stickers, use a scanner that previews URLs, and never enter credentials after scanning an unknown code.",
  default: "That's an important cybersecurity topic! I can help with: password security, phishing awareness, malware protection, 2FA setup, VPN usage, ransomware prevention, public WiFi safety, social media privacy, identity theft, backups, deepfakes, and QR code scams. What would you like to know more about?"
};

function getBotResponse(input: string): string {
  const lower = input.toLowerCase();
  for (const [key, response] of Object.entries(knowledgeBase)) {
    if (lower.includes(key)) return response;
  }
  return knowledgeBase.default;
}

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      text: "Hello! I'm your Cyber Safety Assistant. Ask me anything about cybersecurity—passwords, phishing, malware, 2FA, and more. I'm here to help keep you safe online!",
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: Message = {
      id: messages.length,
      text: input.trim(),
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Simulate typing delay
    await new Promise((resolve) => setTimeout(resolve, 800 + Math.random() * 1000));

    const botResponse = getBotResponse(userMsg.text);
    const botMsg: Message = {
      id: messages.length + 1,
      text: botResponse,
      sender: 'bot',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, botMsg]);
    setIsTyping(false);
  };

  const quickQuestions = [
    "How do I create a strong password?",
    "What is phishing?",
    "How does 2FA work?",
    "Is public WiFi safe?",
    "What is ransomware?",
    "How to spot a deepfake?",
  ];

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-4">
            <Bot className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">AI Assistant</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            Cyber Safety <span className="text-gradient">Assistant</span>
          </h1>
          <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
            Ask any cybersecurity question and get instant, expert guidance powered by our comprehensive knowledge base.
          </p>
        </div>

        {/* Chat Container */}
        <div className="glass-card overflow-hidden flex flex-col" style={{ height: '65vh' }}>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                  msg.sender === 'bot'
                    ? 'bg-[#00E5C0]/20'
                    : 'bg-white/10'
                }`}>
                  {msg.sender === 'bot' ? (
                    <Bot className="w-4 h-4 text-[#00E5C0]" />
                  ) : (
                    <User className="w-4 h-4 text-white" />
                  )}
                </div>
                <div
                  className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed ${
                    msg.sender === 'bot'
                      ? 'bg-white/5 text-white/90 rounded-tl-sm'
                      : 'bg-[#00E5C0]/15 text-white rounded-tr-sm'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-3">
                <div className="shrink-0 w-8 h-8 rounded-full bg-[#00E5C0]/20 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-[#00E5C0]" />
                </div>
                <div className="bg-white/5 p-4 rounded-2xl rounded-tl-sm">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-[#00E5C0] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-[#00E5C0] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-[#00E5C0] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Questions */}
          {messages.length < 3 && (
            <div className="px-4 sm:px-6 pb-2">
              <p className="text-xs text-[var(--text-secondary)] mb-2">Quick questions:</p>
              <div className="flex flex-wrap gap-2">
                {quickQuestions.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setInput(q);
                    }}
                    className="text-xs px-3 py-1.5 rounded-full bg-white/5 text-[var(--text-secondary)] hover:bg-[#00E5C0]/10 hover:text-[#00E5C0] transition-all"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-4 border-t border-white/10">
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about cybersecurity..."
                className="input-cyber flex-1"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                className="btn-cyber px-4 py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
