import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ClipboardCheck, ChevronRight, ChevronLeft, CheckCircle,
  XCircle, Trophy, RotateCcw, Download, Award, Star
} from 'lucide-react';
import { quizQuestions } from '../data/quizData';

type QuizState = 'intro' | 'playing' | 'review' | 'completed';

export default function Quiz() {
  const [state, setState] = useState<QuizState>('intro');
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState(false);
  const navigate = useNavigate();

  const question = quizQuestions[currentQ];
  const totalQuestions = quizQuestions.length;
  const answeredCount = Object.keys(answers).length;
  const progress = ((currentQ + 1) / totalQuestions) * 100;

  const handleAnswer = (optionIndex: number) => {
    if (answers[currentQ] !== undefined) return;
    setAnswers((prev) => ({ ...prev, [currentQ]: optionIndex }));
    setShowExplanation(true);
  };

  const handleNext = () => {
    if (currentQ < totalQuestions - 1) {
      setCurrentQ((prev) => prev + 1);
      setShowExplanation(false);
    } else {
      setState('completed');
    }
  };

  const handlePrev = () => {
    if (currentQ > 0) {
      setCurrentQ((prev) => prev - 1);
      setShowExplanation(true);
    }
  };

  const calculateScore = () => {
    let correct = 0;
    for (let i = 0; i < totalQuestions; i++) {
      if (answers[i] === quizQuestions[i].correctAnswer) correct++;
    }
    return correct;
  };

  const score = calculateScore();
  const percentage = Math.round((score / totalQuestions) * 100);

  const getGrade = () => {
    if (percentage >= 90) return { grade: 'A+', label: 'Cyber Security Expert', color: 'text-[#00E5C0]' };
    if (percentage >= 80) return { grade: 'A', label: 'Security Savvy', color: 'text-[#00E5C0]' };
    if (percentage >= 70) return { grade: 'B', label: 'Well Informed', color: 'text-blue-400' };
    if (percentage >= 60) return { grade: 'C', label: 'Getting There', color: 'text-yellow-400' };
    return { grade: 'D', label: 'Keep Learning', color: 'text-red-400' };
  };

  const grade = getGrade();

  const generateCertificate = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 850;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    const gradient = ctx.createLinearGradient(0, 0, 1200, 850);
    gradient.addColorStop(0, '#0B0F17');
    gradient.addColorStop(1, '#121A26');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1200, 850);

    // Border
    ctx.strokeStyle = '#00E5C0';
    ctx.lineWidth = 4;
    ctx.strokeRect(40, 40, 1120, 770);

    // Inner border
    ctx.strokeStyle = 'rgba(0, 229, 192, 0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(55, 55, 1090, 740);

    // Corner decorations
    const drawCorner = (x: number, y: number, rotate: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rotate);
      ctx.strokeStyle = '#00E5C0';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, -20);
      ctx.lineTo(0, 0);
      ctx.lineTo(20, 0);
      ctx.stroke();
      ctx.restore();
    };
    drawCorner(60, 60, 0);
    drawCorner(1140, 60, Math.PI / 2);
    drawCorner(1140, 790, Math.PI);
    drawCorner(60, 790, -Math.PI / 2);

    // Title
    ctx.fillStyle = '#00E5C0';
    ctx.font = 'bold 48px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('CERTIFICATE OF COMPLETION', 600, 150);

    // Subtitle
    ctx.fillStyle = '#A7B3C7';
    ctx.font = '28px Arial';
    ctx.fillText('Cyber Safety Awareness Program', 600, 200);

    // Decorative line
    ctx.strokeStyle = '#00E5C0';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(350, 230);
    ctx.lineTo(850, 230);
    ctx.stroke();

    // Body text
    ctx.fillStyle = '#F2F5F9';
    ctx.font = '24px Arial';
    ctx.fillText('This certifies that the bearer has successfully completed', 600, 300);
    ctx.fillText('the Cyber Safety Awareness Quiz demonstrating knowledge', 600, 340);
    ctx.fillText('of essential cybersecurity practices and threat awareness.', 600, 380);

    // Score
    ctx.fillStyle = '#00E5C0';
    ctx.font = 'bold 72px Arial';
    ctx.fillText(`${percentage}%`, 600, 480);

    ctx.fillStyle = grade.color.replace('text-', '');
    const colorMap: Record<string, string> = {
      'text-[#00E5C0]': '#00E5C0',
      'text-blue-400': '#60A5FA',
      'text-yellow-400': '#FACC15',
      'text-red-400': '#F87171',
    };
    ctx.fillStyle = colorMap[grade.color] || '#00E5C0';
    ctx.font = 'bold 36px Arial';
    ctx.fillText(`Grade: ${grade.grade} - ${grade.label}`, 600, 540);

    // Score details
    ctx.fillStyle = '#A7B3C7';
    ctx.font = '22px Arial';
    ctx.fillText(`Correct Answers: ${score} out of ${totalQuestions}`, 600, 600);

    // Date
    const date = new Date().toLocaleDateString('en-US', {
      year: 'numeric', month: 'long', day: 'numeric'
    });
    ctx.fillStyle = '#F2F5F9';
    ctx.font = '20px Arial';
    ctx.fillText(`Date: ${date}`, 600, 660);

    // Footer
    ctx.fillStyle = '#00E5C0';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('SafeNet Haven', 600, 730);
    ctx.fillStyle = '#A7B3C7';
    ctx.font = '18px Arial';
    ctx.fillText('Cyber Safety Awareness Initiative', 600, 760);

    // Logo area
    ctx.fillStyle = '#00E5C0';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('www.safenethaven.org', 80, 790);

    const link = document.createElement('a');
    link.download = `cyber-safety-certificate-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  if (state === 'intro') {
    return (
      <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8 min-h-screen flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00E5C0]/10 mb-6">
            <ClipboardCheck className="w-4 h-4 text-[#00E5C0]" />
            <span className="text-sm text-[#00E5C0] font-medium">Cyber Safety Quiz</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Test Your <span className="text-gradient">Cyber Knowledge</span>
          </h1>
          <p className="text-[var(--text-secondary)] text-lg mb-8 leading-relaxed">
            Challenge yourself with {totalQuestions} multiple-choice questions covering passwords, phishing, malware, and online safety. Earn a certificate upon completion!
          </p>
          <div className="glass-card p-6 mb-8 text-left">
            <h3 className="text-white font-semibold mb-4">What to expect:</h3>
            <ul className="space-y-3">
              {[
                `${totalQuestions} multiple-choice questions`,
                'Instant feedback with explanations',
                'Progress tracking throughout',
                'Personalized certificate of completion',
                'Learn while you play',
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-[var(--text-secondary)]">
                  <Star className="w-4 h-4 text-[#00E5C0]" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <button
            onClick={() => setState('playing')}
            className="btn-cyber inline-flex items-center gap-2 text-lg px-8 py-4"
          >
            Start Quiz
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  if (state === 'completed') {
    return (
      <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8 min-h-screen flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center">
          <div className="mb-6">
            <Trophy className={`w-16 h-16 mx-auto ${grade.color}`} />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">
            Quiz <span className="text-gradient">Complete!</span>
          </h1>

          <div className="glass-card p-8 mb-8">
            <div className="text-6xl font-bold text-[#00E5C0] mb-2">{percentage}%</div>
            <div className={`text-2xl font-semibold ${grade.color} mb-4`}>
              Grade {grade.grade} - {grade.label}
            </div>
            <p className="text-[var(--text-secondary)] mb-6">
              You answered <span className="text-white font-medium">{score}</span> out of{' '}
              <span className="text-white font-medium">{totalQuestions}</span> questions correctly.
            </p>

            {/* Score breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
              {[
                { label: 'Correct', value: score, color: 'text-green-400' },
                { label: 'Incorrect', value: totalQuestions - score, color: 'text-red-400' },
                { label: 'Answered', value: answeredCount, color: 'text-blue-400' },
                { label: 'Total', value: totalQuestions, color: 'text-[#00E5C0]' },
              ].map((stat, i) => (
                <div key={i} className="bg-white/5 rounded-xl p-3">
                  <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{stat.label}</div>
                </div>
              ))}
            </div>

            {percentage >= 60 && (
              <button
                onClick={generateCertificate}
                className="btn-cyber inline-flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download Certificate
              </button>
            )}
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={() => {
                setState('review');
                setCurrentQ(0);
                setShowExplanation(true);
              }}
              className="btn-outline inline-flex items-center gap-2"
            >
              Review Answers
            </button>
            <button
              onClick={() => {
                setState('intro');
                setCurrentQ(0);
                setAnswers({});
                setShowExplanation(false);
              }}
              className="btn-outline inline-flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Retake Quiz
            </button>
            <button
              onClick={() => navigate('/pledge')}
              className="btn-cyber inline-flex items-center gap-2"
            >
              <Award className="w-4 h-4" />
              Take the Pledge
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative z-10 pt-24 pb-10 px-4 sm:px-6 lg:px-8 min-h-screen">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <span className="mono text-xs uppercase tracking-[0.14em] text-[#00E5C0]">
              Question {currentQ + 1} of {totalQuestions}
            </span>
            <h1 className="text-xl font-semibold text-white mt-1">
              {state === 'review' ? 'Review Mode' : 'Cyber Safety Quiz'}
            </h1>
          </div>
          <div className="text-right">
            <div className="text-sm text-[var(--text-secondary)]">
              Score: {Object.entries(answers).filter(([k, v]) => v === quizQuestions[Number(k)].correctAnswer).length}
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="progress-bar mb-8">
          <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
        </div>

        {/* Question */}
        <div className="glass-card p-6 lg:p-8 mb-6">
          <h2 className="text-lg sm:text-xl text-white font-medium mb-6 leading-relaxed">
            {question.question}
          </h2>

          {/* Options */}
          <div className="space-y-3">
            {question.options.map((option, i) => {
              const isSelected = answers[currentQ] === i;
              const isCorrect = i === question.correctAnswer;
              const showResult = showExplanation || state === 'review';

              let optionClass = 'glass-card p-4 text-left w-full transition-all flex items-start gap-3 ';
              if (showResult) {
                if (isCorrect) optionClass += 'border-green-500/40 bg-green-500/10 ';
                else if (isSelected && !isCorrect) optionClass += 'border-red-500/40 bg-red-500/10 ';
                else optionClass += 'opacity-50 ';
              } else if (isSelected) {
                optionClass += 'border-[#00E5C0]/40 bg-[#00E5C0]/10 ';
              } else {
                optionClass += 'glass-card-hover cursor-pointer hover:bg-white/10 ';
              }

              return (
                <button
                  key={i}
                  onClick={() => handleAnswer(i)}
                  disabled={showExplanation || state === 'review'}
                  className={optionClass}
                >
                  <span className={`w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium shrink-0 ${
                    showResult
                      ? isCorrect
                        ? 'bg-green-500 text-white'
                        : isSelected
                        ? 'bg-red-500 text-white'
                        : 'bg-white/10 text-[var(--text-secondary)]'
                      : isSelected
                      ? 'bg-[#00E5C0] text-[#0B0F17]'
                      : 'bg-white/10 text-[var(--text-secondary)]'
                  }`}>
                    {showResult ? (
                      isCorrect ? <CheckCircle className="w-4 h-4" /> :
                      isSelected ? <XCircle className="w-4 h-4" /> :
                      String.fromCharCode(65 + i)
                    ) : (
                      String.fromCharCode(65 + i)
                    )}
                  </span>
                  <span className="text-white/90 text-sm sm:text-base">{option}</span>
                </button>
              );
            })}
          </div>

          {/* Explanation */}
          {(showExplanation || state === 'review') && (
            <div className="mt-6 p-4 rounded-xl bg-[#00E5C0]/5 border border-[#00E5C0]/20 animate-fade-in">
              <h4 className="text-[#00E5C0] font-medium mb-2 flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Explanation
              </h4>
              <p className="text-sm text-[var(--text-secondary)] leading-relaxed">
                {question.explanation}
              </p>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={handlePrev}
            disabled={currentQ === 0}
            className="btn-outline inline-flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </button>

          {state === 'review' ? (
            <button
              onClick={() => {
                setState('intro');
                setCurrentQ(0);
                setAnswers({});
                setShowExplanation(false);
              }}
              className="btn-outline inline-flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Retake
            </button>
          ) : (
            <button
              onClick={handleNext}
              disabled={answers[currentQ] === undefined}
              className="btn-cyber inline-flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {currentQ === totalQuestions - 1 ? 'Finish' : 'Next'}
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Question Navigator */}
        <div className="mt-8 glass-card p-4">
          <div className="flex flex-wrap gap-2 justify-center">
            {quizQuestions.map((_, i) => (
              <button
                key={i}
                onClick={() => {
                  setCurrentQ(i);
                  setShowExplanation(state === 'review' || answers[i] !== undefined);
                }}
                className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                  i === currentQ
                    ? 'bg-[#00E5C0] text-[#0B0F17]'
                    : answers[i] !== undefined
                    ? answers[i] === quizQuestions[i].correctAnswer
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-red-500/20 text-red-400'
                    : 'bg-white/5 text-[var(--text-secondary)] hover:bg-white/10'
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
